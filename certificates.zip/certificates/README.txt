Exact certificate exporter for the sparse affine family

Python standard library only. No external packages, eigensolver, path
tracker or network access are used.

Examples, run from this directory:

  python certificate_export.py --blocks 3 2 1 --target 5,0,1,2,3,4 --output examples/jordan_3_2_1.json
  python certificate_export.py --blocks 2 --target 1,0 --output examples/jordan_2.json
  python certificate_export.py --blocks 1 1 2 --target 1,2,3,0 --output examples/jordan_1_1_2.json
  python verify_certificate.py --output certificate_verification.json

The optional target gives zero-based permutation images. Without it, the
identity target is emitted. All matrix indices in JSON are one-based.
The output preserves the input coordinate order; construction_block_order
records a cyclic order starting at a non-singleton chain. An all-singleton
input is rejected because it is precisely the zero-base obstruction.

The source theorem's unit-entry construction has g+1 controlled entries.
For N=2 it therefore has two entries, while one entry already suffices for
S_2. The certificate explicitly marks this exception. Likewise R_* is a
nonzero-collision radius but not a universality threshold at N=2, since the
inner C_2 group already equals S_2.

Products have rightmost factor acting first. The chronological command
list is their reversal. The compiler uses zero-winding lifted star paths,
not the longer two-generator lifted loop counted as a single elementary
segment. Sheet labels are canonical branch-cycle labels; identifying them
with poles of a separately labeled numerical spectrum is a separate task.

The software emits certificates for the specific analytically proved
family. It does not decide the monodromy group of a general matrix pencil,
compute a Jordan form, isolate every collision root, trace matrix poles,
simulate dynamics, or claim a novel general symbolic-computation method.

Verification run:
  41 profile cases (all 37 nonzero nilpotent partitions in dimensions
  2 through 7, plus four reordered cases beginning with singletons);
  1,083 full integer determinants on complete interpolation grids;
  every target permutation in dimensions 2 through 6 (872 targets),
  plus 300 fixed-seed targets in dimensions 7, 8, and 15;
  independently enumerated canonical S_N group orders through N=7.

These are finite implementation checks; the general claims have proofs.

Construction cost:
  O(N+g) index operations/storage for sparse matrix and structural records;
  O(N+g+W) with a target word of W<=2N(N-1) elementary traversals.
  This excludes big-integer arithmetic and serialization. The collision
  coefficients have O(N log N) bits and are computed by integer powers.
  Dense output would require Theta(N^2) entries.

The norm record includes nonzero_row_order; its squared-norm array is in
that explicit order, which can differ from sorted numerical row indices.
For the separate full-local-cycle construction for all Jordan types, see
GENERAL_FUSION_README.txt and check_general_fusion.py.
