"""Independent exact Sylvester determinant audit of the discriminant formula."""
from math import comb,gcd
from pathlib import Path
import json
import argparse

def det(matrix):
    a=[r[:] for r in matrix];n=len(a);prev=1;sgn=1
    for k in range(n-1):
        r=next((i for i in range(k,n) if a[i][k]),None)
        if r is None:return 0
        if r!=k:a[k],a[r]=a[r],a[k];sgn=-sgn
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                value=a[i][j]*pivot-a[i][k]*a[k][j]
                assert value%prev==0
                a[i][j]=value//prev
            a[i][k]=0
        prev=pivot
    return sgn*a[-1][-1]

def resultant(coeff,deriv):
    n=len(coeff)-1;m=len(deriv)-1;size=m+n
    rows=[]
    for i in range(m):rows.append([0]*i+coeff+[0]*(size-i-len(coeff)))
    for i in range(n):rows.append([0]*i+deriv+[0]*(size-i-len(deriv)))
    return det(rows)

records=[];total=0
for N,g,k,c in [(2,1,1,1),(3,1,1,2),(3,2,1,1),(4,2,1,1),(5,2,1,2),(6,2,2,5),(6,3,1,1),(6,4,1,1),(7,3,1,2),(8,6,1,1)]:
    d=gcd(N,g);n=N//d;h=g//d
    assert n*k-h*c==1 and gcd(c,N)==1
    
    Dprime=max(g-h,k)
    degree_bound=g*(N-1)+N*Dprime
    sigma=(-1)**((N-1)*(N+2)//2)
    for t in range(degree_bound+1):
        coeff=[0]*(N+1)
        for j in range(d+1):coeff[n*j]+=(-1)**j*comb(d,j)*t**(h*j)
        coeff[c]-=t**k
        deriv=[coeff[i]*(N-i) for i in range(N)]
        disc=(-1)**(N*(N-1)//2)*resultant(coeff,deriv)
        wanted=sigma*t**(g*(N-1)+d-1)*(N**N-(-1)**c*c**c*(N-c)**(N-c)*t)
        assert disc==wanted,(N,g,k,c,t,disc,wanted)
        total+=1
    records.append({'N':N,'g':g,'k':k,'c':c,'sigma':sigma,'degree_bound':degree_bound,'complete_grid_checks':degree_bound+1})
report={'status':'passed','parameter_cases':len(records),'full_integer_sylvester_determinants':total,'scope':'Complete interpolation grids establish these finite polynomial discriminant identities. General identity audited algebraically.','records':records}
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('independent_discriminant_report.json'))
args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='records'}))
