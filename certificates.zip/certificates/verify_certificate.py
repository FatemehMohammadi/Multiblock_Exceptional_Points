"""Independent finite checks of certificate_export, using full determinants.

The exact determinant checks run complete interpolation grids for every
nonzero nilpotent partition through dimension seven. They establish the
finite identities tested, not the all-dimension theorem. Compiler checks
evaluate every target permutation through dimension six and a fixed set
of larger targets; no numerical eigenvalue continuation is performed.
"""
from __future__ import annotations

import argparse
from collections import deque
from fractions import Fraction
from itertools import permutations
import json
from math import factorial, gcd
from pathlib import Path
import random

from certificate_export import build_certificate, compile_target


def determinant(matrix: list[list[int]]) -> int:
    """Full fraction-free elimination, independent of the determinant lemma."""
    a = [row[:] for row in matrix]
    n, previous, sign = len(a), 1, 1
    if n == 0:
        return 1
    for k in range(n - 1):
        pivot = next((i for i in range(k, n) if a[i][k]), None)
        if pivot is None:
            return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            sign = -sign
        value = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                numerator = a[i][j] * value - a[i][k] * a[k][j]
                quotient, remainder = divmod(numerator, previous)
                if remainder:
                    raise ArithmeticError("nonexact fraction-free elimination")
                a[i][j] = quotient
            a[i][k] = 0
        previous = value
    return sign * a[-1][-1]


def matrix_rank(matrix: list[list[int]]) -> int:
    a = [[Fraction(x) for x in row] for row in matrix]
    rank = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(rank, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        for i in range(rank + 1, len(a)):
            ratio = a[i][col] / a[rank][col]
            for j in range(col, len(a[0])):
                a[i][j] -= ratio * a[rank][j]
        rank += 1
        if rank == len(a):
            break
    return rank


def partitions(n: int, maximum: int | None = None):
    if n == 0:
        yield []
        return
    for first in range(min(n, maximum or n), 0, -1):
        for rest in partitions(n - first, first):
            yield [first] + rest


def dense(entries, n):
    matrix = [[0] * n for _ in range(n)]
    for row, col, value in entries:
        matrix[row - 1][col - 1] += value
    return matrix


def cycle_partition(p):
    unseen = set(range(len(p)))
    lengths = []
    while unseen:
        start = next(iter(unseen))
        i, size = start, 0
        while i in unseen:
            unseen.remove(i)
            size += 1
            i = p[i]
        assert i == start
        lengths.append(size)
    return sorted(lengths)


def graph_check(certificate):
    n = certificate["dimension"]
    adjacency = [[] for _ in range(n)]
    for entries, is_controlled in ((certificate["fixed_matrix_entries"], False),
                                   (certificate["profile_entries"], True)):
        for row, col, value in entries:
            assert value == 1
            adjacency[col - 1].append((row - 1, is_controlled))
    starts = [i for i, edges in enumerate(adjacency) if len(edges) == 2]
    assert len(starts) == 1
    start = starts[0]
    observed = []
    for first_choice in range(2):
        seen, controlled, i = {start}, 0, start
        target, weight = adjacency[i][first_choice]
        controlled += weight
        while target != start:
            assert target not in seen
            seen.add(target)
            assert len(adjacency[target]) == 1
            target, weight = adjacency[target][0]
            controlled += weight
        observed.append((len(seen), controlled))
    assert sorted(observed) == [(n - 1, certificate["number_of_blocks"]),
                                (n, certificate["number_of_blocks"])]


def exact_family_checks(maximum=7):
    reports, total = [], 0
    cases = []
    for n in range(2, maximum + 1):
        cases.extend(p for p in partitions(n) if max(p) > 1)
    
    
    cases.extend([[1, 3, 1, 2], [1, 1, 2], [1, 2, 1], [1, 1, 1, 2]])
    for blocks in cases:
        c = build_certificate(blocks)
        n, g = c["dimension"], c["number_of_blocks"]
        a = dense(c["fixed_matrix_entries"], n)
        b = dense(c["profile_entries"], n)
        assert matrix_rank(b) == g
        minor = [[b[i - 1][j - 1]
                  for j in c["rank_certificate"]["nonzero_minor_columns"]]
                 for i in c["rank_certificate"]["nonzero_minor_rows"]]
        assert determinant(minor) == 1
        gram = [[sum(b[i][k] * b[j][k] for k in range(n))
                 for j in range(n)] for i in range(n)]
        assert all(gram[i][j] == 0 for i in range(n) for j in range(n) if i != j)
        assert sorted(x for i, row in enumerate(gram) if (x := row[i])) == [1] * (g - 1) + [2]
        norm = c["norm_certificate"]
        row_order = norm["nonzero_row_order"]
        assert sorted(row_order) == sorted(c["rank_certificate"]["only_nonzero_rows"])
        assert [gram[i - 1][i - 1] for i in row_order] == norm["nonzero_row_squared_norms"]
        graph_check(c)
        count = 0
        for lam in range(n + 1):
            for t in range(g + 1):
                matrix = [[(lam if i == j else 0) - a[i][j] - t * b[i][j]
                           for j in range(n)] for i in range(n)]
                assert determinant(matrix) == lam ** n - t ** g * (1 + lam)
                count += 1
        scalar = c["scalar_cover_certificate"]
        point = Fraction(**scalar["critical_point"])
        value = Fraction(**scalar["nonzero_critical_value"])
        assert point ** n - value * (1 + point) == 0
        assert n * point ** (n - 1) - value == 0
        assert n * (n - 1) * point ** (n - 2) != 0
        assert 1 + point != 0
        local = c["power_pullback"]["local_generator_images"]
        assert cycle_partition(local) == [n // gcd(n, g)] * gcd(n, g)
        reports.append({"blocks": blocks, "dimension": n,
                        "full_integer_determinants": count,
                        "interpolation_degree_bounds": {"lambda": n, "t": g},
                        "rank_minor_gram_graph_and_branch_data": "passed"})
        total += count
    return {"profile_cases": len(cases), "full_integer_determinants": total,
            "case_reports": reports}


def _generators(n):
    
    rho = list(range(n))
    for i in range(1, n):
        rho[i] = 1 if i == n - 1 else i + 1
    rho_inverse = [0] * n
    for i, j in enumerate(rho):
        rho_inverse[j] = i
    tau = list(range(n))
    tau[0], tau[1] = 1, 0
    return {"rho": tuple(rho), "rho_inverse": tuple(rho_inverse), "tau": tuple(tau)}


def _apply_chronological(tokens, n):
    generators = _generators(n)
    result = list(range(n))
    for token in tokens:
        result = [generators[token][image] for image in result]
    return tuple(result)


def compiler_checks():
    exact, larger = 0, 0
    for n in range(2, 7):
        for target in permutations(range(n)):
            c = compile_target(target)
            assert _apply_chronological(c["chronological_scalar_commands"], n) == target
            word = c["scalar_path_product"]
            assert word.count("rho") == word.count("rho_inverse")
            assert len(word) <= 2 * n * (n - 1)
            for star in c["star_certificates"]:
                actual = _apply_chronological(reversed(star["scalar_path_product"]), n)
                expected = list(range(n))
                u, v = star["transposition"]
                expected[u], expected[v] = v, u
                assert actual == tuple(expected)
            exact += 1
    rng = random.Random(27102026)
    for n in (7, 8, 15):
        for _ in range(100):
            target = list(range(n))
            rng.shuffle(target)
            c = compile_target(tuple(target))
            assert _apply_chronological(c["chronological_scalar_commands"], n) == tuple(target)
            larger += 1
    orders = []
    for n in range(2, 8):
        gen = _generators(n)
        identity = tuple(range(n))
        seen, queue = {identity}, deque([identity])
        while queue:
            p = queue.popleft()
            for token in ("rho", "tau"):
                q = tuple(gen[token][p[i]] for i in range(n))
                if q not in seen:
                    seen.add(q)
                    queue.append(q)
        assert len(seen) == factorial(n)
        orders.append({"dimension": n, "generated_group_order": len(seen)})
    return {"all_permutation_targets_dimensions_2_through_6": exact,
            "larger_fixed_seed_targets": larger,
            "abstract_group_orders": orders,
            "scope": "Canonical abstract permutations; analytical proofs identify actual paths"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rejected = False
    try:
        build_certificate([1, 1, 1])
    except ValueError:
        rejected = True
    assert rejected
    report = {"status": "passed", "exact_family": exact_family_checks(),
              "compiler": compiler_checks(), "zero_base_rejected": True}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"],
                      "profile_cases": report["exact_family"]["profile_cases"],
                      "full_integer_determinants": report["exact_family"]["full_integer_determinants"],
                      "compiler_targets": sum(report["compiler"][k] for k in
                          ("all_permutation_targets_dimensions_2_through_6", "larger_fixed_seed_targets"))}, indent=2))


if __name__ == "__main__":
    main()
