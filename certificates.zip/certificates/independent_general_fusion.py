"""Independent full-matrix audit of the Bezout companion construction.

This verifies finite polynomial instances, not the all-partition proof.
No code from the proposed construction/checker is imported.
"""
from fractions import Fraction
from math import comb,gcd
from pathlib import Path
import json
import argparse

def partitions(n,m=None):
    if not n:
        yield ();return
    if m is None:m=n
    for a in range(min(n,m),0,-1):
        for tail in partitions(n-a,a):yield (a,)+tail

def balanced_indices(parts):
    N=sum(parts);g=len(parts);avg=Fraction(N,g);pmax=max(parts)
    first=parts.index(pmax);rest=[i for i in range(g) if i!=first]
    order=[first];s=pmax-avg
    assert 0<=s<pmax-1
    while rest:
        feasible=next((j for j,i in enumerate(rest) if parts[i]<avg and s+parts[i]-avg>=0),None)
        if feasible is None:
            feasible=next((j for j,i in enumerate(rest) if parts[i]>avg),None)
        if feasible is None:
            assert s==0 and all(parts[i]==avg for i in rest)
            order.extend(rest);break
        i=rest.pop(feasible);order.append(i);s+=parts[i]-avg
        assert 0<=s<pmax-1,(parts,order,s)
    return order

def bezout(N,g):
    d=gcd(N,g);n=N//d;h=g//d
    choices=[(k,c) for k in range(1,g+1) for c in range(1,N) if n*k-h*c==1 and gcd(c,N)==1]
    assert choices,(N,g)
    return (*choices[0],d,n,h)

def determinant(mat):
    a=[r[:] for r in mat];n=len(a);prev=1;sgn=1
    for k in range(n-1):
        z=next((j for j in range(k,n) if a[j][k]),None)
        if z is None:return 0
        if z!=k:a[k],a[z]=a[z],a[k];sgn=-sgn
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator=a[i][j]*pivot-a[i][k]*a[k][j]
                assert numerator%prev==0
                a[i][j]=numerator//prev
            a[i][k]=0
        prev=pivot
    return sgn*a[-1][-1]

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=Path(__file__).with_name('independent_general_fusion_report.json'))
args=parser.parse_args()

records=[];count=0
for N in range(2,13):
    for parts in partitions(N):
        g=len(parts)
        if N==g:continue
        k,c,d,n,h=bezout(N,g)
        order=balanced_indices(parts);p=[parts[i] for i in order]
        starts=[];ends=[];offset=0
        A=[[0]*N for _ in range(N)];B=[[0]*N for _ in range(N)]
        for size in parts:
            starts.append(offset);ends.append(offset+size-1)
            for j in range(size-1):A[offset+j][offset+j+1]=1
            offset+=size
        prefix=[];total=0
        for size in p:total+=size;prefix.append(total)
        entries=[]
        for i in range(g-1):entries.append((ends[order[i]],starts[order[i+1]],1))
        for j in range(1,d+1):
            row=j*h;excess=prefix[row-1]-j*n
            assert 0<=excess<p[0]-1
            entries.append((ends[order[row-1]],starts[order[0]]+excess,(-1)**(j+1)*comb(d,j)))
        exponent=prefix[k-1]-c
        assert 1<=exponent<=p[0]-1
        entries.append((ends[order[k-1]],starts[order[0]]+exponent,1))
        assert len({(i,j) for i,j,a in entries})==g+d
        for i,j,a in entries:B[i][j]=a
        assert sum(a!=0 for row in B for a in row)==g+d
        rows=[ends[i] for i in order]
        cols=[starts[i] for i in order]
        assert abs(determinant([[B[i][j] for j in cols] for i in rows]))==1
        for lam in range(N+1):
            for t in range(g+1):
                matrix=[[(lam if i==j else 0)-A[i][j]-t*B[i][j] for j in range(N)] for i in range(N)]
                got=determinant(matrix)
                want=(lam**n-t**h)**d-t**k*lam**(N-c)
                assert got==want,(parts,order,lam,t,got,want)
                count+=1
        
        for s in [Fraction(1,2),Fraction(-1),Fraction(2)]:
            lam=s**g/(1-s)**k;t=s**N/(1-s)**c
            assert (lam**n-t**h)**d-t**k*lam**(N-c)==0
            assert 1-t**h/lam**n==s
        s=Fraction(N,N-c);lam=s**g/(1-s)**k;t=s**N/(1-s)**c
        b=Fraction((-1)**c*N**N,c**c*(N-c)**(N-c))
        assert t==b
        aa=lam**n-t**h
        dl=d*n*lam**(n-1)*aa**(d-1)-t**k*(N-c)*lam**(N-c-1)
        dt=-d*h*t**(h-1)*aa**(d-1)-k*t**(k-1)*lam**(N-c)
        dll=d*(d-1)*n*n*lam**(2*n-2)*aa**(d-2)+d*n*(n-1)*lam**(n-2)*aa**(d-1)-t**k*(N-c)*(N-c-1)*lam**(N-c-2)
        assert dl==0 and dt==Fraction(-d,N)*t**(k-1)*lam**(N-c) and dt and dll
        records.append({'parts':parts,'construction_order':[i+1 for i in order],'N':N,'g':g,'d':d,'n':n,'h':h,'k':k,'c':c,'support':g+d,'full_integer_determinants':(N+1)*(g+1)})

orders=0
for N in range(2,21):
    for parts in partitions(N):
        g=len(parts)
        if N==g:continue
        order=balanced_indices(parts);k,c,d,n,h=bezout(N,g)
        prefix=0
        for j,i in enumerate(order,1):
            prefix+=parts[i]
            S=Fraction(prefix)-Fraction(j*N,g)
            assert 0<=S<max(parts)-1
            if j%h==0:assert S.denominator==1
            if j==k:assert 1<=prefix-c<=max(parts)-1
        orders+=1
report={'status':'passed','finite_full_matrix_profiles':len(records),'full_integer_determinants':count,'max_dimension_full_matrix':12,'ordering_profiles_through_dimension_20':orders,'normalization_inverse_and_critical_derivatives':'passed for every full-matrix profile','scope':'Independent finite checks; general claims require the proof.','records':records}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='records'}))
