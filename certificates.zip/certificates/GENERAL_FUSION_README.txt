Balanced-block rank-optimal full-cycle construction
28 October 2026

Paths from the package root:
  The accompanying manuscript gives the complete theorem, proof and scope.
  certificates/check_general_fusion.py: standard-library construction and exact checker.

Precomputed reports and example JSON files are in reference_outputs.zip
at the package root. The commands below generate the complete finite
check records and the exact matrices, construction order, parameters
and determinant checks.

Full checks:
  python certificates/check_general_fusion.py --output /absolute/path/to/general_fusion_report.json

Emit and check a specified profile while preserving the original coordinate
order (only the construction cycle order changes):
  python certificates/check_general_fusion.py --blocks 3 1 --output /absolute/path/to/fusion_jordan_3_1.json
  python certificates/check_general_fusion.py --blocks 3 2 1 --output /absolute/path/to/fusion_jordan_3_2_1.json

The all-partition run covers all 259 nonzero nilpotent Jordan partitions in
dimensions 2 through 12, plus four reordered profiles. The largest additional
profile is (1,8,1,9,1), dimension 20. It performs 15,886 full integer
determinants on complete interpolation grids, 1,315 rational normalization
and inverse checks, and 263 rational simple-critical-point checks. All pass.
The 35 nonzero two-block types through dimension 12 are included.
The exact discriminant formula is checked independently by 1,036 full
Sylvester determinants on complete t-grids for all 28 pairs (N,g) with
2<=N<=8 and 1<=g<N. The interpolation bound is (2N-1)g, without assuming
the claimed factorization or its exact degree. To change this limit use
--discriminant-max-n (default 8).

The general theorem realizes a full local N-cycle and global S_N with rank g
for every nonzero nilpotent Jordan form. It uses g+gcd(N,g) entries, at most
2g. For N>=3, the support is optimal among rank-g profiles for the joint
global/local requirements
when gcd(N,g)=1 or 2, using the new lower-bound lemma. For gcd>=3 this
is an achieved upper bound. See SUPPORT_OBSTRUCTION_README.txt. The g+1-entry construction attains minimum support for global S_N, though
its local permutation can split into several cycles.

The scalar rational cover is classical. Novelty is limited to its constrained
matrix realization with prescribed nilpotent Jordan type, rank and support.
The equality of a spectral polynomial does not transfer Lidskii-chart
codimension results, matrix norms, passivity constants or scattering readout.

The construction gives a full cycle for unequal blocks at minimum rank.
Classifying all local cycle partitions and their profile loci for unequal
blocks remains open.

No numerical root tracking is performed here. The general monodromy and disk
claims follow from the proof; exact finite matrix checks supplement it.
