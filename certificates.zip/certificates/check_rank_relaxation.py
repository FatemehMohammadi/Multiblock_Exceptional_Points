"""Full-matrix exact check of the higher-rank/minimum-support example."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import json


def det(matrix):
    a=[row[:] for row in matrix];n=len(a);previous=1;sign=1
    for k in range(n-1):
        pivot=next((i for i in range(k,n) if a[i][k]),None)
        if pivot is None:return 0
        if pivot!=k:a[k],a[pivot]=a[pivot],a[k];sign=-sign
        value=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator=a[i][j]*value-a[i][k]*a[k][j]
                q,r=divmod(numerator,previous);assert not r
                a[i][j]=q
            a[i][k]=0
        previous=value
    return sign*a[-1][-1]


def audit():
    N=10;A=[[0]*N for _ in range(N)];B=[[0]*N for _ in range(N)]
    for off,size in [(0,7),(7,3)]:
        for j in range(size-1):A[off+j][off+j+1]=1
    entries=[(10,8),(7,9),(8,1)]
    for i,j in entries:B[i-1][j-1]=1
    assert det([[B[i-1][j-1] for j in [9,1,8]] for i in [7,8,10]])==1
    assert sum(any(row) for row in B)==3
    count=0
    for lam in range(11):
        for t in range(4):
            matrix=[[(lam if i==j else 0)-A[i][j]-t*B[i][j] for j in range(N)] for i in range(N)]
            assert det(matrix)==lam**10-t*lam**7-t**3
            count+=1
    for u in [F(-2),F(-1),F(1,3),F(2,3),F(2)]:
        lam=u**3/(1-u);t=u**10/(1-u)**3
        assert lam**10-t*lam**7-t**3==0
        assert t/lam**3==u
    u=F(10,7);lam=u**3/(1-u);t=u**10/(1-u)**3
    assert lam==F(-1000,147)
    assert t==F(-10**10,3**3*7**7)
    assert 10*lam**9-7*t*lam**6==0
    pt=-lam**7-3*t*t;pll=90*lam**8-42*t*lam**5
    assert pt and pll
    return {'status':'passed','blocks':[7,3],'dimension':10,'number_of_blocks':2,'rank_B':3,'support_B':3,'controlled_entries_one_based':entries,'full_integer_determinants':count,'complete_interpolation_degree_bounds':{'lambda':10,'t':3},'rational_normalization_and_inverse_checks':5,'critical_lambda':str(lam),'critical_t':str(t),'simple_critical_point':'P_lambda=0, P_t and P_lambdalambda nonzero','scope':'Exact finite matrix identity and normalization checks. Local cycle/global S10 follow from the rational-cover proof, not numerical continuation.'}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('rank_relaxation_report.json'))
    args=parser.parse_args();result=audit();args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
