"""Exact finite checks for the local-cycle certificate (standard library only).

These checks supplement the analytical proof; a zero certificate is inconclusive.
Run: python test_local_certificate.py [--output report.json]
"""
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
from random import Random
import argparse
import json


def zeros(n, m):
    return [[F(0) for _ in range(m)] for _ in range(n)]


def eye(n):
    a = zeros(n, n)
    for i in range(n):
        a[i][i] = F(1)
    return a


def transpose(a):
    return [list(row) for row in zip(*a)]


def mul(a, b):
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def add(a, b):
    return [[x + y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def scale(c, a):
    return [[c * x for x in row] for row in a]


def power(a, k):
    result = eye(len(a))
    while k:
        if k & 1:
            result = mul(result, a)
        a = mul(a, a)
        k //= 2
    return result


def trace(a):
    return sum((a[i][i] for i in range(len(a))), F(0))


def inverse(a):
    n = len(a)
    e = eye(n)
    aug = [list(row) + e[i] for i, row in enumerate(a)]
    for j in range(n):
        pivot = next(i for i in range(j, n) if aug[i][j])
        aug[j], aug[pivot] = aug[pivot], aug[j]
        c = aug[j][j]
        aug[j] = [x / c for x in aug[j]]
        for i in range(n):
            if i != j:
                c = aug[i][j]
                aug[i] = [x - c * y for x, y in zip(aug[i], aug[j])]
    return [row[n:] for row in aug]


def rank(a):
    a = [list(row) for row in a]
    row = 0
    for j in range(len(a[0])):
        pivot = next((i for i in range(row, len(a)) if a[i][j]), None)
        if pivot is None:
            continue
        a[row], a[pivot] = a[pivot], a[row]
        c = a[row][j]
        a[row] = [x / c for x in a[row]]
        for i in range(row + 1, len(a)):
            c = a[i][j]
            a[i] = [x - c * y for x, y in zip(a[i], a[row])]
        row += 1
        if row == len(a):
            break
    return row


def clean(p):
    return {k: F(v) for k, v in p.items() if v}


def padd(p, q):
    out = dict(p)
    for k, v in q.items():
        out[k] = out.get(k, F(0)) + v
    return clean(out)


def pscale(c, p):
    return clean({k: c * v for k, v in p.items()})


def pmul(p, q):
    out = {}
    for a, x in p.items():
        for b, y in q.items():
            assert len(a) == len(b)
            k = tuple(i + j for i, j in zip(a, b))
            out[k] = out.get(k, F(0)) + x * y
    return clean(out)


def pconstant(c, variables):
    return clean({(0,) * variables: c})


def pdet(a, variables):
    """Leibniz determinant, independent of the low-rank determinant lemma."""
    n = len(a)
    out = {}
    for perm in permutations(range(n)):
        inversions = sum(perm[i] > perm[j] for i in range(n) for j in range(i + 1, n))
        term = pconstant((-1) ** inversions, variables)
        for i, j in enumerate(perm):
            term = pmul(term, a[i][j])
            if not term:
                break
        out = padd(out, term)
    return out


def jordan_base(m, r):
    n = m * r
    a = zeros(n, n)
    for i in range(r):
        for j in range(m - 1):
            a[i * m + j][i * m + j + 1] = F(1)
    return a


def embedding(m, r, k):
    q = zeros(m * r, r)
    for i in range(r):
        q[i * m + k - 1][i] = F(1)
    return q


def pencil_polynomial(a, b, delta_coefficient=None):
    variables = 3 if delta_coefficient is not None else 2
    n = len(a)
    matrix = [[{} for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            p = pconstant(-a[i][j], variables)
            if i == j:
                p = padd(p, {(1,) + (0,) * (variables - 1): F(1)})
            p = padd(p, {(0, 1) + (0,) * (variables - 2): -b[i][j]})
            if delta_coefficient is not None:
                p = padd(p, {(0, 1, 1): -delta_coefficient[i][j]})
            matrix[i][j] = p
    return pdet(matrix, variables)


def chart_case(m, r, rng):
    n = m * r
    a = F(2)
    s = eye(r)
    for i in range(r):
        for j in range(i + 1, r):
            s[i][j] = F(rng.randrange(-2, 3))
    j = zeros(r, r)
    for i in range(r - 1):
        j[i][i + 1] = F(1)
    z = mul(mul(s, j), inverse(s))
    leading = add(scale(a, eye(r)), z)
    c = [[F(rng.randrange(-2, 3)) for _ in range(n - r)] for _ in range(r)]
    d = [[F(rng.randrange(-2, 3)) for _ in range(r)] for _ in range(n - r)]
    lower = mul(mul(d, inverse(leading)), c)
    chart = [leading[i] + c[i] for i in range(r)] + [d[i] + lower[i] for i in range(n - r)]
    rows = [i * m + m - 1 for i in range(r)] + [i for i in range(n) if i % m != m - 1]
    cols = [i * m for i in range(r)] + [i for i in range(n) if i % m != 0]
    b = zeros(n, n)
    for i in range(n):
        for j in range(n):
            b[rows[i]][cols[j]] = chart[i][j]
    return a, z, leading, b


def run_checks():
    rng = Random(1729)
    records = []
    for m in (2, 3, 4):
        for r in (2, 3):
            a0 = jordan_base(m, r)
            q = embedding(m, r, 1)
            e = embedding(m, r, m)
            for case in range(2):
                a, z, leading, b = chart_case(m, r, rng)
                assert rank(b) == r
                u_factor = mul(b, q)
                v_transpose = mul(mul(inverse(leading), transpose(e)), b)
                assert mul(u_factor, v_transpose) == b
                coefficients = [mul(mul(v_transpose, power(a0, m - 1 - j)), u_factor)
                                for j in range(m)]
                assert coefficients[0] == leading
                matrix = [[padd(pconstant(int(i == j), 1),
                                {(k,): -coefficients[k][i][j] / a for k in range(m)})
                           for j in range(r)] for i in range(r)]
                direct_derivative = pdet(matrix, 1).get((1,), F(0))
                k_matrix = mul(mul(mul(transpose(e), b), power(a0, m - 2)), mul(b, q))
                xi = trace(mul(power(z, r - 1), k_matrix))
                derivative_from_xi = -a ** (-r - 1) * xi
                r_corner = mul(mul(transpose(embedding(m, r, m - 1)), b), q)
                s_corner = mul(mul(transpose(e), b), embedding(m, r, 2))
                assert k_matrix == add(mul(leading, r_corner), mul(s_corner, leading))
                psi = trace(mul(power(z, r - 1), add(r_corner, s_corner)))
                derivative_from_psi = -a ** (-r) * psi
                assert direct_derivative == derivative_from_xi == derivative_from_psi
                records.append({'m': m, 'r': r, 'case': case,
                                'strict_transform_derivative': str(direct_derivative),
                                'xi': str(xi), 'psi': str(psi)})

    
    a4 = jordan_base(2, 2)
    b4 = zeros(4, 4)
    for i, j in ((1, 0), (1, 2), (3, 1), (3, 2)):
        b4[i][j] = F(1)
    db4 = zeros(4, 4)
    db4[3][0] = F(-1)
    expected4 = clean({(4, 0, 0): 1, (2, 1, 0): -2, (1, 2, 0): -1,
                       (0, 2, 0): 1, (0, 2, 1): 1})
    assert pencil_polynomial(a4, b4, db4) == expected4
    assert rank(b4) == 2

    
    a6 = jordan_base(3, 2)
    b6 = zeros(6, 6)
    for i, j in ((2, 0), (2, 4), (5, 2), (5, 3)):
        b6[i][j] = F(1)
    expected6 = clean({(6, 0): 1, (3, 1): -2, (3, 2): -1, (0, 2): 1})
    assert pencil_polynomial(a6, b6) == expected6
    assert rank(b6) == 2
    leading6 = mul(mul(transpose(embedding(3, 2, 3)), b6), embedding(3, 2, 1))
    assert leading6 == eye(2)
    g6_at_u_one = pdet([[{}, {(1,): F(-1)}], [{(2,): F(-1)}, {}]], 1)
    assert g6_at_u_one == {(3,): F(-1)}
    assert g6_at_u_one.get((1,), F(0)) == 0
    
    lam = {(2,): F(1)}
    t_numerator = {(6,): F(1)}
    t_denominator = clean({(0,): 1, (3,): 1})
    lam_cubed = pmul(pmul(lam, lam), lam)
    difference_numerator = padd(pmul(lam_cubed, t_denominator), pscale(-1, t_numerator))
    substituted = padd(pmul(difference_numerator, difference_numerator),
                       pscale(-1, pmul(pmul(t_numerator, t_numerator), lam_cubed)))
    assert not substituted
    
    inverse_identity = padd(difference_numerator,
                            pscale(-1, pmul({(1,): F(1)}, pmul(lam, t_numerator))))
    assert not inverse_identity
    return {'status': 'passed', 'rank_chart_cases': len(records),
            'records': records, 'symbolic_four_mode_pencil': 'passed',
            'six_mode_full_matrix_determinant': 'passed',
            'six_mode_vanishing_derivative': 'passed',
            'six_mode_normalization_and_primitive_inverse': 'passed',
            'scope': 'Exact finite checks; the derivative certificate is sufficient, and zero is inconclusive.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = run_checks()
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    print(text, end='')
