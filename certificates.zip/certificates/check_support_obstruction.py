"""Exact finite audit of the small-support obstruction.

Every nonzero nilpotent Jordan type with gcd(N,g)>1 through N=6 is
examined. All support patterns of size g or g+1 are enumerated. The
strongly connected rank-g cases are tested under three nonzero integer
weight assignments, using a full permutation determinant in (lambda,t).
This is finite corroboration of the structural proof, not a decision
procedure for analytic monodromy or an all-size proof.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations
from math import gcd
from pathlib import Path
import argparse
import json
from check_rank_relaxation import audit as audit_rank_relaxation


def partitions(n, maximum=None):
    if not n:
        yield (); return
    for p in range(min(n, n if maximum is None else maximum), 0, -1):
        for tail in partitions(n-p,p):
            yield (p,)+tail


def rank(matrix):
    a=[[Fraction(x) for x in row] for row in matrix]; n=len(a); r=0
    for col in range(n):
        k=next((i for i in range(r,n) if a[i][col]),None)
        if k is None:continue
        a[r],a[k]=a[k],a[r]
        for i in range(r+1,n):
            ratio=a[i][col]/a[r][col]
            if ratio:
                for j in range(col,n):a[i][j]-=ratio*a[r][j]
        r+=1
        if r==n:break
    return r


def strongly_connected(n, edges):
    adjacency=[set() for _ in range(n)]
    for row,col in edges:adjacency[col].add(row)
    for start in range(n):
        reached={start}; queue=[start]
        while queue:
            v=queue.pop()
            for w in adjacency[v]-reached:reached.add(w);queue.append(w)
        if len(reached)!=n:return False
    return True


def add(a,b):
    c=a.copy()
    for power,v in b.items():
        c[power]=c.get(power,0)+v
        if not c[power]:del c[power]
    return c


def multiply(a,b):
    c={}
    for (i,j),v in a.items():
        for (k,l),w in b.items():
            power=(i+k,j+l);c[power]=c.get(power,0)+v*w
    return {power:v for power,v in c.items() if v}


def characteristic(A,B,perms):
    n=len(A); mat=[]
    for i in range(n):
        row=[]
        for j in range(n):
            entry={(1,0):1} if i==j else {}
            if A[i][j]:entry=add(entry,{(0,0):-A[i][j]})
            if B[i][j]:entry=add(entry,{(0,1):-B[i][j]})
            row.append(entry)
        mat.append(row)
    out={}
    for p,sign in perms:
        if any(not mat[i][p[i]] for i in range(n)):continue
        term={(0,0):sign}
        for i,j in enumerate(p):term=multiply(term,mat[i][j])
        out=add(out,term)
    return out


def encode(poly):
    return [{'lambda_power':i,'t_power':j,'coefficient':str(v)} for (i,j),v in sorted(poly.items(),reverse=True)]


def audit(max_n):
    totals=Counter(); cases=[]; witnesses=[]
    for N in range(2,max_n+1):
        perms=[(p,(-1)**sum(p[i]>p[j] for i in range(N) for j in range(i+1,N))) for p in permutations(range(N))]
        for blocks in partitions(N):
            g=len(blocks);d=gcd(N,g)
            if g==N or d==1:continue
            A=[[0]*N for _ in range(N)]; fixed=set();heads=set();ends=set();off=0
            for size in blocks:
                heads.add(off);ends.add(off+size-1)
                for j in range(size-1):A[off+j][off+j+1]=1;fixed.add((off+j,off+j+1))
                off+=size
            record={'blocks':list(blocks),'N':N,'g':g,'d':d}; stats=Counter()
            for s in [g,g+1]:
                for raw in combinations(range(N*N),s):
                    stats['support_patterns']+=1
                    pattern=[divmod(x,N) for x in raw]
                    if not heads <= {j for i,j in pattern} or not ends <= {i for i,j in pattern}:continue
                    if not strongly_connected(N,fixed|set(pattern)):continue
                    stats['strongly_connected_patterns']+=1
                    choices=[[1]*s,([2,1,-1]+list(range(3,s)))[:s],[(-1)**i*(i+1) for i in range(s)]]
                    for weights in choices:
                        B=[[0]*N for _ in range(N)]
                        for (i,j),value in zip(pattern,weights):B[i][j]=value
                        if rank(B)!=g:continue
                        stats['rank_g_weighted_cases']+=1
                        poly=characteristic(A,B,perms);stats['full_symbolic_determinants']+=1
                        constants={j:v for (i,j),v in poly.items() if i==0}
                        if not constants:
                            stats['persistent_zero_cases']+=1;continue
                        assert set(constants)=={g},(blocks,pattern,weights,poly)
                        assert poly.get((N,0))==1
                        assert not fixed&set(pattern),(blocks,pattern,weights)
                        if s==g:
                            assert len(poly)==2
                            stats['pure_binomial_cases']+=1
                            continue
                        assert len(poly)==3,(blocks,pattern,weights,poly)
                        extra=[(power,v) for power,v in poly.items() if power not in [(N,0),(0,g)]]
                        assert len(extra)==1
                        (q,j),value=extra[0]
                        assert 1<=q<N and j>=1
                        delta=N*j+g*q-g*N
                        stats['delta_negative' if delta<0 else 'delta_positive' if delta>0 else 'delta_zero']+=1
                        alpha,beta=-constants[g],-value
                        if delta==0 and d==2 and beta*beta+4*alpha==0:
                            n,h=N//2,g//2;c=Fraction(beta,2)
                            square=multiply({(n,0):1,(0,h):-c},{(n,0):1,(0,h):-c})
                            assert poly==square
                            stats['perfect_square_cases']+=1
                            if not witnesses:
                                witnesses.append({'blocks':list(blocks),'B':B,'polynomial':encode(poly),'square_root':encode({(n,0):1,(0,h):-c})})
            record.update(stats); cases.append(record);totals.update(stats)
    return {'status':'passed','max_dimension':max_n,'Jordan_profiles':len(cases),**dict(totals),'case_reports':cases,'perfect_square_witnesses':witnesses,
            'scope':'All support patterns at the stated finite sizes; three integer weight assignments per strongly connected pattern. Full-matrix symbolic determinants independently verify the trinomial and Newton-leading alternatives. General obstruction and analytic conclusions rely on the proof.'}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-n',type=int,default=6)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('support_obstruction_report.json'))
    args=parser.parse_args();result=audit(args.max_n)
    result['higher_rank_counterexample']=audit_rank_relaxation()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['case_reports','perfect_square_witnesses']},indent=2))
