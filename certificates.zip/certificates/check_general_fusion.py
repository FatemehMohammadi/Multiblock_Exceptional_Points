"""Exact checks for the balanced-block full-cycle construction.

Python standard library only. Full matrices, not reduced determinants, are
used for every interpolation-grid determinant. Finite checks supplement the
all-dimension proof; they do not certify analytic continuation numerically.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from math import comb, gcd
from pathlib import Path
import json


def partitions(n, upper=None):
    if not n:
        yield ()
    else:
        for p in range(min(n, n if upper is None else upper), 0, -1):
            for rest in partitions(n-p, p):
                yield (p,)+rest


def balanced_order(blocks):
    n, g = sum(blocks), len(blocks)
    remaining = list(range(g))
    first = max(remaining, key=lambda j: blocks[j])
    remaining.remove(first)
    order, excess = [first], g*blocks[first]-n
    bound = g*(blocks[first]-1)
    assert 0 <= excess < bound
    while remaining:
        negative = [j for j in remaining if g*blocks[j]-n < 0]
        feasible = [j for j in negative if excess+g*blocks[j]-n >= 0]
        if feasible:
            chosen = feasible[0]
        else:
            nonnegative = [j for j in remaining if g*blocks[j]-n >= 0]
            assert nonnegative
            chosen = nonnegative[0]
        order.append(chosen)
        remaining.remove(chosen)
        excess += g*blocks[chosen]-n
        assert 0 <= excess < bound
    assert excess == 0
    return order


def bezout_choice(n, g):
    d = gcd(n, g)
    small_n, h = n//d, g//d
    k0 = 1 if h == 1 else pow(small_n, -1, h)
    c0 = (small_n*k0-1)//h
    for ell in range(d):
        k, c = k0+ell*h, c0+ell*small_n
        if gcd(c, n) == 1:
            assert 1 <= k <= g and 1 <= c < n
            assert small_n*k-h*c == 1
            return d, small_n, h, k, c
    raise AssertionError('CRT existence failed')


def construct(blocks):
    blocks = tuple(blocks)
    N, g = sum(blocks), len(blocks)
    assert N > g
    order = balanced_order(blocks)
    ordered = [blocks[i] for i in order]
    pmax = ordered[0]
    d, n, h, k, c = bezout_choice(N, g)
    offsets, cursor = [], 0
    for p in blocks:
        offsets.append(cursor)
        cursor += p
    heads = [offsets[i] for i in order]
    ends = [offsets[i]+blocks[i]-1 for i in order]
    A = [[0]*N for _ in range(N)]
    B = [[0]*N for _ in range(N)]
    for off,p in zip(offsets,blocks):
        for j in range(p-1):
            A[off+j][off+j+1] = 1
    for i in range(g-1):
        B[ends[i]][heads[i+1]] = 1
    prefix = [sum(ordered[:j]) for j in range(1,g+1)]
    exponents = []
    for j in range(1,d+1):
        row = j*h-1
        e = prefix[row]-j*n
        assert 0 <= e <= pmax-1
        B[ends[row]][heads[0]+e] += (-1)**(j+1)*comb(d,j)
        exponents.append({'row': row+1, 'exponent': e})
    e = prefix[k-1]-c
    assert 1 <= e <= pmax-1
    B[ends[k-1]][heads[0]+e] += 1
    assert sum(x != 0 for row in B for x in row) == g+d
    return {'blocks':list(blocks),'order':[i+1 for i in order],
            'ordered_blocks':ordered,'N':N,'g':g,'d':d,'n':n,'h':h,
            'k':k,'c':c,'A':A,'B':B,'heads':heads,'ends':ends,
            'leading_exponents':exponents,'extra_exponent':e}


def determinant(matrix):
    """Full integer Bareiss elimination with exact pivoting."""
    a = [row[:] for row in matrix]
    n = len(a)
    if not n:
        return 1
    previous, sign = 1, 1
    for k in range(n-1):
        if not a[k][k]:
            pivot = next((i for i in range(k+1,n) if a[i][k]),None)
            if pivot is None:
                return 0
            a[k],a[pivot] = a[pivot],a[k]
            sign = -sign
        pivot = a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator = a[i][j]*pivot-a[i][k]*a[k][j]
                assert numerator % previous == 0
                a[i][j] = numerator//previous
            a[i][k] = 0
        previous = pivot
    return sign*a[-1][-1]


def characteristic(r, lam, t):
    return (lam**r['n']-t**r['h'])**r['d']-t**r['k']*lam**(r['N']-r['c'])


def derivative_lam(r, lam, t, order):
    total = 0
    for j in range(r['d']+1):
        power = r['N']-j*r['n']
        if power >= order:
            factor = 1
            for z in range(order):
                factor *= power-z
            total += (-1)**j*comb(r['d'],j)*t**(j*r['h'])*factor*lam**(power-order)
    power = r['N']-r['c']
    if power >= order:
        factor = 1
        for z in range(order):
            factor *= power-z
        total -= t**r['k']*factor*lam**(power-order)
    return total


def check_discriminant(r):
    """Independent full Sylvester determinant on a complete t-grid."""
    N,g,d,n,h,k,c = (r[z] for z in ['N','g','d','n','h','k','c'])
    bound = (2*N-1)*g
    alpha = g*(N-1)+d-1
    sigma = (-1)**((N-1)*(N+2)//2)
    for t in range(bound+1):
        coefficients = [0]*(N+1)
        for j in range(d+1):
            coefficients[N-j*n] += (-1)**j*comb(d,j)*t**(j*h)
        coefficients[N-c] -= t**k
        descending = coefficients[::-1]
        derivative = [(N-j)*descending[j] for j in range(N)]
        size = 2*N-1
        sylvester = []
        for shift in range(N-1):
            sylvester.append([0]*shift+descending+[0]*(size-shift-len(descending)))
        for shift in range(N):
            sylvester.append([0]*shift+derivative+[0]*(size-shift-len(derivative)))
        actual = (-1)**(N*(N-1)//2)*determinant(sylvester)
        expected = sigma*t**alpha*(N**N-(-1)**c*c**c*(N-c)**(N-c)*t)
        assert actual == expected,(r['blocks'],t,actual,expected)
    return {'N':N,'g':g,'k':k,'c':c,'sylvester_determinants':bound+1,
            'interpolation_degree_bound_t':bound,'central_discriminant_order':alpha}


def check_profile(blocks):
    r = construct(blocks)
    N,g = r['N'],r['g']
    columns = r['heads'][1:]+r['heads'][:1]
    minor = [[r['B'][row][col] for col in columns] for row in r['ends']]
    rank_minor = determinant(minor)
    assert abs(rank_minor) == 1
    count = 0
    for lam in range(N+1):
        for t in range(g+1):
            matrix = [[(lam if i == j else 0)-r['A'][i][j]-t*r['B'][i][j]
                       for j in range(N)] for i in range(N)]
            assert determinant(matrix) == characteristic(r,lam,t),(blocks,lam,t)
            count += 1
    for s in [F(-2),F(-1),F(1,3),F(2,3),F(2)]:
        lam,t = s**g/(1-s)**r['k'],s**N/(1-s)**r['c']
        assert characteristic(r,lam,t) == 0
        assert 1-t**r['h']/lam**r['n'] == s
    critical_s = F(N,N-r['c'])
    critical_lam = critical_s**g/(1-critical_s)**r['k']
    b = F((-1)**r['c']*N**N,r['c']**r['c']*(N-r['c'])**(N-r['c']))
    assert critical_s**N/(1-critical_s)**r['c'] == b
    assert derivative_lam(r,critical_lam,b,1) == 0
    assert derivative_lam(r,critical_lam,b,2) != 0
    q = critical_lam**r['n']-b**r['h']
    pt = -r['d']*r['h']*b**(r['h']-1)*q**(r['d']-1)-r['k']*b**(r['k']-1)*critical_lam**(N-r['c'])
    assert pt != 0
    return {'blocks':list(blocks),'construction_order':r['order'],
            'ordered_blocks':r['ordered_blocks'],'N':N,'g':g,'d':r['d'],
            'n':r['n'],'h':r['h'],'k':r['k'],'c':r['c'],
            'support_size':g+r['d'],'rank_minor':rank_minor,
            'integer_determinants':count,
            'interpolation_degree_bounds':{'lambda':N,'t':g},
            'normalization_and_inverse_checks':5,
            'critical_lambda':str(critical_lam),'critical_t':str(b),
            'P_lambda_zero_P_lambdalambda_and_P_t_nonzero':True,
            'balanced_prefix_and_exponents':'passed'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--max-n',type=int,default=12)
    parser.add_argument('--discriminant-max-n',type=int,default=8)
    parser.add_argument('--blocks',type=int,nargs='+',help='Emit and check one exact matrix certificate instead of the full partition run.')
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    if args.blocks:
        if any(p < 1 for p in args.blocks) or max(args.blocks) < 2:
            parser.error('positive block sizes with a nonzero nilpotent base are required')
        certificate = construct(args.blocks)
        certificate['verification'] = check_profile(args.blocks)
        certificate['index_conventions'] = 'Dense A/B arrays and heads/ends use zero-based indices; order uses one-based block indices.'
        output = args.output or Path(__file__).with_name('general_fusion_certificate.json')
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(json.dumps(certificate,indent=2)+'\n')
        print('Exact matrix certificate and full interpolation-grid checks written to',output)
        return
    profiles = [p for N in range(2,args.max_n+1) for p in partitions(N) if max(p)>1]
    profiles += [(1,1,2),(1,3,1,2),(1,1,1,1,1,2),(1,8,1,9,1)]
    records = [check_profile(p) for p in profiles]
    pairs = {}
    for p in profiles:
        if sum(p) <= args.discriminant_max_n:
            pairs.setdefault((sum(p),len(p)),p)
    discriminants = [check_discriminant(construct(p)) for p in pairs.values()]
    report = {'status':'passed','max_partition_dimension':args.max_n,
              'partition_profiles':len(profiles)-4,'additional_reordered_profiles':4,
              'profile_cases':len(records),
              'full_integer_determinants':sum(r['integer_determinants'] for r in records),
              'two_block_profiles_through_max_n':sum(len(r['blocks'])==2 and r['N']<=args.max_n for r in records),
              'normalization_and_inverse_checks':5*len(records),
              'exact_simple_critical_point_checks':len(records),
              'discriminant_parameter_pairs':len(discriminants),
              'full_sylvester_determinants':sum(r['sylvester_determinants'] for r in discriminants),
              'discriminant_case_reports':discriminants,
              'zero_base':'All-singleton partitions excluded; N=2 permits J2 only.',
              'scope':'Finite full-matrix exact checks. General local/global/disk group statements rely on the manuscript proof.',
              'case_reports':records}
    output = args.output or Path(__file__).with_name('general_fusion_report.json')
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in {'case_reports','discriminant_case_reports'}},indent=2))


if __name__ == '__main__':
    main()
