"""Export exact certificates for the manuscript's sparse affine family.

This is a constructive specialization of the proved family, not a general
matrix-pencil monodromy solver. All matrix indices in JSON are one-based;
canonical spectral-sheet labels and permutation images are zero-based.
No floating-point eigensolver or path tracker is used.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import json
from math import gcd
from pathlib import Path
import sys


def compose(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    """Function product left*right: right acts first."""
    return tuple(left[right[i]] for i in range(len(left)))


def permutation_power(p: tuple[int, ...], exponent: int) -> tuple[int, ...]:
    """Power by cycle offsets, with O(N) index operations."""
    answer = list(range(len(p)))
    visited = [False] * len(p)
    for start in range(len(p)):
        if visited[start]:
            continue
        cycle = []
        i = start
        while not visited[i]:
            visited[i] = True
            cycle.append(i)
            i = p[i]
        shift = exponent % len(cycle)
        for position, item in enumerate(cycle):
            answer[item] = cycle[(position + shift) % len(cycle)]
    return tuple(answer)


def canonical_generators(n: int) -> tuple[tuple[int, ...], tuple[int, ...]]:
    rho = tuple([0] + list(range(2, n)) + [1])
    tau = tuple([1, 0] + list(range(2, n)))
    return rho, tau


def _nontrivial_cycles(p: tuple[int, ...]) -> list[list[int]]:
    marked = [False] * len(p)
    cycles = []
    for start in range(len(p)):
        if marked[start]:
            continue
        cycle = []
        i = start
        while not marked[i]:
            marked[i] = True
            cycle.append(i)
            i = p[i]
        if len(cycle) > 1:
            cycles.append(cycle)
    return cycles


def compile_target(target: tuple[int, ...]) -> dict:
    """A star decomposition and exact scalar-path word for a permutation.

    Products have rightmost factor acting first. Reversing the exported
    elementary product gives its chronological path-command sequence.
    """
    n = len(target)
    valid = n >= 2
    seen = [False] * n
    for image in target:
        if type(image) is not int or not 0 <= image < n or seen[image]:
            valid = False
            break
        seen[image] = True
    if not valid:
        raise ValueError("target must contain each sheet label 0,...,N-1 once")
    endpoints = []
    for cycle in _nontrivial_cycles(target):
        
        
        if 0 in cycle:
            pivot = cycle.index(0)
            cycle = cycle[pivot:] + cycle[:pivot]
            endpoints.extend(reversed(cycle[1:]))
        else:
            endpoints.append(cycle[0])
            endpoints.extend(reversed(cycle[1:]))
            endpoints.append(cycle[0])
    word = []
    star_certificates = []
    for endpoint in endpoints:
        j = endpoint - 1
        if j > (n - 1) // 2:
            j -= n - 1
        prefix = "rho" if j >= 0 else "rho_inverse"
        suffix = "rho_inverse" if j >= 0 else "rho"
        factors = [prefix] * abs(j) + ["tau"] + [suffix] * abs(j)
        word.extend(factors)
        star_certificates.append({
            "transposition": [0, endpoint],
            "conjugating_exponent": j,
            "scalar_path_product": factors,
            "winding_about_zero": 0,
            "closes_under_power_pullback": True,
        })
    result = list(range(n))
    
    
    
    
    for endpoint in endpoints:
        result[0], result[endpoint] = result[endpoint], result[0]
    if tuple(result) != target:
        raise ArithmeticError("internal product-certificate mismatch")
    if len(endpoints) > 2 * (n - 1) or len(word) > 2 * n * (n - 1):
        raise ArithmeticError("internal compiler-bound mismatch")
    return {
        "target_images": list(target),
        "product_convention": "rightmost factor acts first",
        "star_certificates": star_certificates,
        "scalar_path_product": word,
        "chronological_scalar_commands": list(reversed(word)),
        "evaluated_images": list(result),
        "number_of_stars": len(endpoints),
        "elementary_path_traversals": len(word),
        "star_bound": 2 * (n - 1),
        "elementary_path_bound": 2 * n * (n - 1),
        "total_winding_about_zero": 0,
    }


def _rational(value: Fraction) -> dict[str, int]:
    return {"numerator": value.numerator, "denominator": value.denominator}


def build_certificate(blocks: list[int], target: tuple[int, ...] | None = None) -> dict:
    """Build the unit-entry profile without changing the input coordinate order."""
    if not blocks or any(type(p) is not int or p <= 0 for p in blocks):
        raise ValueError("block sizes must be positive integers")
    if max(blocks) == 1:
        raise ValueError("the all-singleton type is the zero-base obstruction")
    n, g = sum(blocks), len(blocks)
    starts = []
    current = 1
    fixed = []
    for p in blocks:
        starts.append(current)
        fixed.extend([current + k, current + k + 1, 1] for k in range(p - 1))
        current += p
    ends = [start + p - 1 for start, p in zip(starts, blocks)]
    first = next(i for i, p in enumerate(blocks) if p >= 2)
    order = [first] + [i for i in range(g) if i != first]
    profile = []
    minor_rows = []
    minor_cols = []
    closure_edges = []
    for position, block in enumerate(order):
        successor = order[(position + 1) % g]
        row, col = ends[successor], starts[block]
        profile.append([row, col, 1])
        closure_edges.append([row, col])
        minor_rows.append(row)
        minor_cols.append(col)
    shortcut_row = ends[order[1 % g]]
    shortcut_col = starts[first] + 1
    profile.append([shortcut_row, shortcut_col, 1])
    b = Fraction((-1) ** (n + 1) * n ** n, (n - 1) ** (n - 1))
    c = Fraction(-n, n - 1)
    d = gcd(n, g)
    rho, tau = canonical_generators(n)
    a = compose(rho, tau)
    local_generator = permutation_power(a, g)
    target = tuple(range(n)) if target is None else target
    if len(target) != n:
        raise ValueError("target length must equal the sum of the block sizes")
    return {
        "format": "spectral-permutation-certificate-v1",
        "scope": "The manuscript's proved sparse family; not a general monodromy solver",
        "matrix_index_base": 1,
        "sheet_index_base": 0,
        "input_block_sizes": blocks,
        "construction_block_order": [i + 1 for i in order],
        "dimension": n,
        "number_of_blocks": g,
        "fixed_matrix_entries": fixed,
        "profile_entries": profile,
        "characteristic_polynomial": {
            "variables": ["lambda", "t"],
            "monomials": [
                {"coefficient": 1, "powers": [n, 0]},
                {"coefficient": -1, "powers": [1, g]},
                {"coefficient": -1, "powers": [0, g]},
            ],
        },
        "rank_certificate": {
            "nonzero_minor_rows": minor_rows,
            "nonzero_minor_columns": minor_cols,
            "minor_in_displayed_order": "identity",
            "minor_determinant": 1,
            "only_nonzero_rows": ends,
            "rank": g,
        },
        "graph_certificate": {
            "classical_support": "Wielandt digraph W_N, up to relabeling",
            "controlled_closures": closure_edges,
            "controlled_shortcut": [shortcut_row, shortcut_col],
            "cycle_lengths": [n, n - 1],
            "controlled_factors_per_cycle": [g, g],
            "cycles_intersect": True,
        },
        "norm_certificate": {
            "operator_norm_squared": 2,
            "frobenius_norm_squared": g + 1,
            "nonzero_row_order": minor_rows,
            "nonzero_row_squared_norms": [2] + [1] * (g - 1),
        },
        "scalar_cover_certificate": {
            "cover": "T=lambda^N/(1+lambda)",
            "critical_point": _rational(c),
            "nonzero_critical_value": _rational(b),
            "branch_cycle_lengths": {"zero": [n], "nonzero_critical_value": [2] + [1] * (n - 2),
                                     "infinity": [n - 1, 1]},
            "rho_images": list(rho),
            "tau_images": list(tau),
            "zero_meridian_images": list(a),
            "branch_cycle_relation": "zero_meridian * tau = rho",
        },
        "power_pullback": {
            "map": "T=t^g",
            "collision_polynomial_nonzero": {
                "variable": "t",
                "coefficients_by_degree": {
                    str(g): (n - 1) ** (n - 1),
                    "0": -((-1) ** (n + 1)) * n ** n,
                },
            },
            "local_cycle_lengths": [n // d] * d,
            "local_generator_images": list(local_generator),
            "inner_cyclic_group_order": n // d,
            "outer_group": f"S_{n}",
            "threshold_radius_power": {"power": g, "value": _rational(abs(b))},
            "universal_group_already_inside_threshold": n == 2,
            "proof": "The winding-kernel image is normal in S_N and contains the nonzero meridian transposition",
        },
        "resource_bounds": {
            "profile_rank": g,
            "rank_is_minimal_for_transitive_action": True,
            "profile_entry_count": g + 1,
            "minimum_entry_count_for_S_N": 1 if n == 2 else g + 1,
            "entry_count_is_minimal_for_this_profile": n >= 3,
            "amplitude_bound_power": {"power": g, "value": 3 * n},
            "basis": "the fixed standard Jordan-chain coordinates",
        },
        "two_closed_lift_generators": {
            "first": "L=rho*(a^N*rho^(-(N-1)))^(g-1)",
            "first_winding": g,
            "first_permutation_images": list(rho),
            "second": "tau",
            "second_winding": 0,
            "second_permutation_images": list(tau),
            "a": "a based meridian about zero with N-cycle permutation",
        },
        "target_compilation": compile_target(target),
        "labeling_limit": (
            "Sheet 0 is the sheet approaching the simple pole -1 in the scalar cover; "
            "labels 1,...,N-1 follow the rho orbit starting at its partner in tau. "
            "These canonical labels require identification with any measured or numerically labeled spectrum."
        ),
        "verification_limit": (
            "Exact symbolic and finite permutation data only. The analytical proof identifies "
            "these permutations with actual based loops; no numerical path tracking or dynamics is performed."
        ),
    }


def _parse_target(text: str) -> tuple[int, ...]:
    try:
        return tuple(int(part.strip()) for part in text.split(","))
    except ValueError as exc:
        raise argparse.ArgumentTypeError("target must be a comma-separated list of integer images") from exc


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--blocks", nargs="+", type=int, required=True,
                        help="positive Jordan-block sizes; at least one must exceed one")
    parser.add_argument("--target", type=_parse_target,
                        help="optional zero-based permutation images, for example 5,0,1,2,3,4")
    parser.add_argument("--output", type=Path, required=True,
                        help="JSON destination; parent directories are created")
    args = parser.parse_args()
    try:
        certificate = build_certificate(args.blocks, args.target)
    except ValueError as exc:
        parser.error(str(exc))
    
    
    
    if hasattr(sys, "set_int_max_str_digits"):
        sys.set_int_max_str_digits(0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
