Minimum-rank support obstruction and rank-relaxation example

Run from the package root, writing reports to your chosen paths:
  python certificates/check_support_obstruction.py --output /absolute/path/to/support.json
  python certificates/check_rank_relaxation.py --output /absolute/path/to/rank_example.json
Keep the two Python files together; the first imports the second.
The complete reproduce.py driver includes both checks.

The mathematical proof is in the accompanying manuscript.
At rank g and gcd(N,g)>1, a full local N-cycle requires at least g+2
entries. For N>=3 and simultaneous global S_N/full local cycle, the
minimum is g+1 for gcd=1 and g+2 for gcd=2. For gcd>=3 only the bounds
g+2 and g+gcd(N,g) are proved.

The finite audit enumerates all 1,094,599 patterns of sizes g or g+1
for all ten relevant Jordan types through dimension six. Three fixed
nonzero integer assignments are considered per strongly connected
pattern. The 3,015 rank-g cases have full symbolic matrix determinants;
eight perfect-square boundary cases occur. This does not enumerate all
complex coefficients or replace the general proof.

For J7+J3, the three unit entries (10,8),(7,9),(8,1) give rank three,
support three, a full local ten-cycle and global S10. At minimum rank
two the support minimum is instead four. The example receives 44 full
integer determinants on a complete interpolation grid plus exact rank,
normalization, inverse and critical-point checks. No numerical S10
closure enumeration or ten-root continuation is claimed.
