import unittest
from stronger_checks import (exact_polynomial_checks, group_and_compiler_checks,
                             evaluate_word, star_word, from_cycles, compile_permutation)


class ExactAlgebraTests(unittest.TestCase):
    def test_characteristic_and_cofactor_complete_grids(self):
        report = exact_polynomial_checks()
        self.assertEqual(sum(x["determinants"] for x in report), 126)
        self.assertEqual(sum(x["cofactors"] for x in report), 108)

    def test_group_orders_and_compiler(self):
        result = group_and_compiler_checks()
        self.assertEqual(sum(x["cases"] for x in result["compiler"]), 224)

    def test_star_conjugations_and_composition_order(self):
        for n in range(3, 13):
            for j in range(1, n):
                self.assertEqual(evaluate_word(star_word(j, n), n), from_cycles(n, [[0, j]]))
        self.assertEqual(evaluate_word(compile_permutation((1, 2, 0, 3))[0], 4), (1, 2, 0, 3))


if __name__ == "__main__":
    unittest.main()
