"""Exact quartic discriminant checks and its reproducible rational-map figure."""
from pathlib import Path
from fractions import Fraction as F
import argparse
import json


def determinant(a):
    a = [[F(x) for x in row] for row in a]
    answer = F(1)
    for j in range(len(a)):
        pivot = next((i for i in range(j, len(a)) if a[i][j]), None)
        if pivot is None:
            return F(0)
        if pivot != j:
            a[pivot], a[j] = a[j], a[pivot]
            answer = -answer
        d = a[j][j]
        answer *= d
        for i in range(j + 1, len(a)):
            ratio = a[i][j] / d
            for k in range(j + 1, len(a)):
                a[i][k] -= ratio * a[j][k]
            a[i][j] = 0
    return answer


def discriminant(t, delta):
    p = [F(1), F(0), -2*t, -t*t, (1+delta)*t*t]
    dp = [F(4), F(0), -4*t, -t*t]
    sylvester = []
    for j in range(3):
        sylvester.append([F(0)]*j + p + [F(0)]*(2-j))
    for j in range(4):
        sylvester.append([F(0)]*j + dp + [F(0)]*(3-j))
    return determinant(sylvester)


def exact_checks():
    count = 0
    for t in map(F, range(-7, 8)):
        for delta in map(F, range(4)):
            formula = t**6 * (256*delta**2*(1+delta)
                                -32*(8+9*delta)*t-27*t**2)
            assert discriminant(t, delta) == formula
            count += 1
    
    
    
    delta = F(3, 4)
    for y, critical, lam in [(F(1,6), F(14,27), F(7,9)),
                              (F(-3,2), F(-18), F(3))]:
        assert (y*y+delta)**2/(1+y) == critical
        assert y*y+delta == lam
        assert discriminant(critical, delta) == 0
    return {"status": "passed", "sylvester_determinants": count,
            "interpolation_degree_bounds": {"t": 14, "delta": 3},
            "critical_values": ["14/27", "-18"],
            "critical_eigenvalues": ["7/9", "3"],
            "scope": "Exact quartic identities; general disk groups are proved in the manuscript."}


def figure(output):
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "svg.fonttype": "none"})
    fig = plt.figure(figsize=(5.5, 3.15))
    grid = fig.add_gridspec(2, 2, height_ratios=[1.7, 0.8])
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1]),
            fig.add_subplot(grid[1, :])]
    positive = np.linspace(-0.6, 1.2, 900)
    negative = np.linspace(-2.7, -1.08, 900)
    f = lambda y: (y*y+0.75)**2/(1+y)
    axes[0].plot(positive, f(positive), color="#1966a0", lw=1.8)
    axes[0].scatter([1/6], [14/27], color="#a82a29", zorder=3)
    axes[0].axhline(14/27, color="#a82a29", lw=0.9, ls="--")
    axes[0].annotate(r"$b_+=14/27$", (1/6,14/27), (0.30,1.22),
                     arrowprops={"arrowstyle": "-", "color": "#a82a29"})
    axes[0].set(xlabel=r"$y>-1$", ylabel=r"$t=f(y)$", ylim=(0,3.6),
                title="(a) Positive branch")
    axes[1].plot(negative, f(negative), color="#1966a0", lw=1.8)
    axes[1].scatter([-1.5], [-18], color="#a82a29", zorder=3)
    axes[1].axhline(-18, color="#a82a29", lw=0.9, ls="--")
    axes[1].annotate(r"$b_-=-18$", (-1.5,-18), (-2.4,-13.8),
                     arrowprops={"arrowstyle": "-", "color": "#a82a29"})
    axes[1].set(xlabel=r"$y<-1$", ylabel=r"$t=f(y)$", ylim=(-52,-10),
                title="(b) Negative branch")
    ax=axes[2]; left, first, second, right=0.03,14/27,18,200
    for lo,hi,color,label in [(left,first,"#d8e9f5",r"$C_2$"+"\norder 2"),
                              (first,second,"#f6dfb7",r"$C_2\wr C_2$"+"\norder 8"),
                              (second,right,"#d9ead5",r"$S_4$"+"\norder 24")]:
        ax.axvspan(lo,hi,ymin=0.25,ymax=0.78,color=color)
        ax.text(np.sqrt(lo*hi),0.52,label,ha="center",va="center")
    for x in (first,second):ax.axvline(x,color="#a82a29",ls="--",lw=1)
    ax.set_xscale("log");ax.set(xlim=(left,right),ylim=(0,1),yticks=[],
        xlabel=r"Disk radius $R$ (log scale)",title=r"(c) Disk group, $|t|<R$")
    ax.text(first,0.10,r"$14/27$",ha="center",color="#a82a29")
    ax.text(second,0.10,r"$18$",ha="center",color="#a82a29")
    for a in axes[:2]:a.grid(alpha=0.2)
    fig.tight_layout(w_pad=1.0, h_pad=.7, pad=.5)
    output.mkdir(parents=True,exist_ok=True)
    for ext in ("pdf","svg","png"):
        fig.savefig(output/("quartic_branch_values."+ext),dpi=240,
                    bbox_inches="tight")
    plt.close(fig)


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output-root", type=Path, required=True)
    args=p.parse_args();root=args.output_root.resolve()
    report=exact_checks();(root/"results").mkdir(parents=True,exist_ok=True)
    (root/"results/quartic_example_report.json").write_text(json.dumps(report,indent=2)+"\n")
    figure(root/"figures")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
