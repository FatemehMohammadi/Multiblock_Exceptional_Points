"""Reproduce exact checks and stable pointwise readout asymptotics.

Run with Python, NumPy and Matplotlib. No proprietary packages are needed.
The readout curves evaluate omega=0 and t=r, not a numerical supremum over
all frequencies or control phases; the uniform supremum is proved in text.
"""
from pathlib import Path
import argparse
import csv
import json
import math
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from stronger_checks import exact_polynomial_checks, group_and_compiler_checks


ROOT = Path(__file__).resolve().parents[1]


def staged_integer_checks(results):
    """Rerun the existing full-integer checkers without changing archives."""
    reports={}
    with tempfile.TemporaryDirectory(prefix="integer_checks_",dir=results) as temp:
        stage=Path(temp)
        for name in ("verify_higher_rank.py","verify_all_jordan.py"):
            shutil.copy2(ROOT/name,stage/name)
        for script,report in [("verify_higher_rank.py","higher_rank_verification.json"),
                              ("verify_all_jordan.py","all_jordan_verification.json")]:
            run=subprocess.run([sys.executable,str(stage/script)],capture_output=True,text=True)
            if run.returncode:
                raise RuntimeError(run.stdout+run.stderr)
            (results/(script+".log")).write_text(run.stdout+run.stderr)
            data=json.loads((stage/report).read_text())
            if data["status"]!="passed":
                raise ValueError(data)
            (results/report).write_text(json.dumps(data,indent=2)+"\n")
            reports[report.removesuffix(".json")]={key:value for key,value in data.items() if key!="cases"}
    return reports


def matrices(m, delta):
    n = 2 * m
    a = np.zeros((n, n), dtype=complex)
    for start in (0, m):
        for j in range(m-1):
            a[start+j, start+j+1] = 1
    b = np.zeros_like(a)
    b[m-1, 0] = 2
    b[2*m-1, 0] = 1
    b[m-2, m] = 1
    b[m-1, m] = -(1+delta)
    return a, b


def critical_radius(m, delta):
    y = delta / (m + math.sqrt(m*m + (2*m-1)*delta))
    return (y*y + delta) ** m / (1+y)


def pointwise(m, radius, a_scale=0.5, b_scale=1.5, kappa=3.0, gamma=0.1):
    delta_a = a_scale * radius ** (1/m)
    delta_b = b_scale * radius ** (1/m)
    a0, ba = matrices(m, delta_a)
    _, bb = matrices(m, delta_b)
    lam = 1j * kappa
    ga = np.linalg.inv(lam*np.eye(2*m) - a0-radius*ba)
    gb = np.linalg.inv(lam*np.eye(2*m) - a0-radius*bb)
    r0 = np.linalg.inv(lam*np.eye(2*m) - a0)
    u = r0[:, m-1]
    v = r0[m, :].conj()
    port = (u/np.linalg.norm(u) + v/np.linalg.norm(v))/math.sqrt(2)
    
    prefactor = gamma * radius * (delta_b-delta_a)
    full = prefactor * np.linalg.norm(ga[:,m-1]) * np.linalg.norm(gb[m,:])
    mixed = prefactor * abs(np.vdot(port,ga[:,m-1])) * abs(gb[m,:]@port)
    pa = (lam**m-radius)**2-radius**2*(lam-delta_a)
    pb = (lam**m-radius)**2-radius**2*(lam-delta_b)
    site = gamma * radius**2 * (delta_b-delta_a)*abs(lam)**(2*m-1)/abs(pa*pb)
    fm = sum(kappa**(-2*j) for j in range(1,m+1))
    common = gamma * (b_scale-a_scale)
    exact_constants = (common*kappa**(-2*m-1),common*fm/2,common*fm)
    power_site, power_mix = 2+1/m,1+1/m
    tca, tcb = critical_radius(m,delta_a),critical_radius(m,delta_b)
    if not tca < radius < tcb:
        raise ValueError("retained hypotheses do not have the asserted different phases")
    direct_outer_site = prefactor*abs(ga[0,m-1])*abs(gb[m,0])
    if not np.isclose(site,direct_outer_site,rtol=2e-12,atol=0):
        raise ValueError("cofactor and resolvent-difference calculations disagree")
    return {"m":m,"r":float(radius),"delta_a":delta_a,"delta_b":delta_b,
            "critical_a":tca,"critical_b":tcb,"site":site,"mixed":mixed,"full":full,
            "site_leading":exact_constants[0]*radius**power_site,
            "mixed_leading":exact_constants[1]*radius**power_mix,
            "full_leading":exact_constants[2]*radius**power_mix,
            "site_power":power_site,"mixed_power":power_mix,
            "site_scaled":site/(exact_constants[0]*radius**power_site),
            "mixed_scaled":mixed/(exact_constants[1]*radius**power_mix),
            "full_scaled":full/(exact_constants[2]*radius**power_mix),
            "site_over_mixed_over_r":site/mixed/radius,
            "site_over_mixed_over_r_limit":exact_constants[0]/exact_constants[1]}


def plot(rows, dest):
    plt.rcParams.update({"font.family":"DejaVu Serif","font.size":9,
                         "axes.labelsize":9,"legend.fontsize":8.5,
                         "axes.titlesize":9.5,"svg.fonttype":"none"})
    fig, axes = plt.subplots(1,2,figsize=(5.5,2.5),constrained_layout=True)
    chosen=[x for x in rows if x["m"]==2]
    radii=np.array([x["r"] for x in chosen])
    for key,label,color,style in [
        ("site",r"Site $|\Delta S_{11}|$","#9a3412","-"),
        ("mixed",r"Coherent $|\Delta(v^*Sv)|$","#0369a1","-"),
        ("full",r"Full $\|\Delta S\|_2$","#166534","--")]:
        axes[0].loglog(radii,[x[key] for x in chosen],style,color=color,label=label,lw=1.8)
    axes[0].set_ylabel(r"Response contrast")
    axes[0].set_title(r"(a) Contrasts, $m=2$")
    axes[0].legend(loc="lower right",framealpha=.95)
    axes[0].grid(which="both",alpha=.18)
    axes[0].set_xlabel(r"Control radius $\rho$")
    for m,color in [(2,"#9a3412"),(3,"#0369a1"),(4,"#166534")]:
        chosen=[x for x in rows if x["m"]==m]
        x=np.array([z["r"] for z in chosen]);y=np.array([z["site_over_mixed_over_r"] for z in chosen])
        axes[1].semilogx(x,y,color=color,label=rf"$m={m}$",lw=1.8)
        axes[1].axhline(chosen[0]["site_over_mixed_over_r_limit"],ls="--",lw=.9,color=color,alpha=.65)
    axes[1].set_yscale("log")
    axes[1].set_xlabel(r"Control radius $\rho$")
    axes[1].set_ylabel(r"$|\Delta S_{11}|\,/\,(\rho\,|\Delta(v^*Sv)|)$")
    axes[1].set_title(r"(b) Site/coherent ratio")
    axes[1].legend(loc="center right",bbox_to_anchor=(1,.68))
    axes[1].grid(which="both",alpha=.18)
    dest.mkdir(parents=True,exist_ok=True)
    for ext in ("pdf","svg","png"):
        fig.savefig(dest/f"channel_separation.{ext}",dpi=220)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output-root",type=Path,default=ROOT)
    args=parser.parse_args()
    started=time.perf_counter()
    output=args.output_root.resolve();results=output/"results";results.mkdir(parents=True,exist_ok=True)
    integer_reports=staged_integer_checks(results)
    exact=exact_polynomial_checks();groups=group_and_compiler_checks()
    rows=[pointwise(m,float(r)) for m in (2,3,4) for r in np.logspace(-2,-7,31)]
    slopes=[]
    for m in (2,3,4):
        selected=[x for x in rows if x["m"]==m and x["r"]<=1e-4]
        record={"m":m,"fit_window":"r<=1e-4 on fixed 31-point grid","fit_count":len(selected)}
        for key in ("site","mixed","full"):
            record[key+"_slope"]=float(np.polyfit(np.log([x["r"] for x in selected]),np.log([x[key] for x in selected]),1)[0])
            record[key+"_scaled_at_smallest_r"]=selected[-1][key+"_scaled"]
        slopes.append(record)
    with (results/"pointwise_channel_separation.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (results/"pointwise_channel_separation.json").write_text(json.dumps(rows,indent=2)+"\n")
    raw={}
    for m in (2,3,4):
        ga_saved=[];gb_saved=[]
        chosen=[x for x in rows if x["m"]==m]
        for row in chosen:
            a0,ba=matrices(m,row["delta_a"]);_,bb=matrices(m,row["delta_b"])
            ga_saved.append(np.linalg.inv(3j*np.eye(2*m)-a0-row["r"]*ba))
            gb_saved.append(np.linalg.inv(3j*np.eye(2*m)-a0-row["r"]*bb))
        r0=np.linalg.inv(3j*np.eye(2*m)-a0)
        u=r0[:,m-1];v=r0[m,:].conj()
        raw[f"m{m}_ga"]=np.array(ga_saved);raw[f"m{m}_gb"]=np.array(gb_saved)
        raw[f"m{m}_coherent_port"]=(u/np.linalg.norm(u)+v/np.linalg.norm(v))/math.sqrt(2)
        raw[f"m{m}_radii"]=np.array([x["r"] for x in chosen])
        raw[f"m{m}_delta_a"]=np.array([x["delta_a"] for x in chosen])
        raw[f"m{m}_delta_b"]=np.array([x["delta_b"] for x in chosen])
    np.savez_compressed(results/"pointwise_resolvents.npz",**raw)
    summary={"protocol":{"m":[2,3,4],"a":.5,"b":1.5,"kappa":3.0,"gamma":.1,
                          "r_grid":"31 logarithmically spaced radii from 1e-2 to 1e-7",
                          "frequency":0.0,"control_phase":0.0,
                          "scope":"pointwise illustrative evaluations; uniform-frequency supremum is analytical",
                          "subtraction":"rank-one resolvent identity and exact scalar cofactor formula"},
             "pointwise_rows":len(rows),"different_partitions_verified":len(rows),
             "exact_polynomial_checks":exact,"permutation_checks":groups,
             "integer_checker_reports":integer_reports,
             "asymptotic_slopes":slopes,"elapsed_seconds":time.perf_counter()-started,
             "versions":{"python":platform.python_version(),"numpy":np.__version__,"matplotlib":matplotlib.__version__}}
    (results/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    plot(rows,output/"figures")
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    main()
