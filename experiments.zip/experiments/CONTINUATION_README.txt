Independent numerical continuation checks -- 28 October 2026

Run with Python and NumPy:

  python check_root_continuation.py

Or choose a report destination:

  python check_root_continuation.py --output /absolute/path/to/new_report.json

Nine cases reproduce the concrete monodromy examples through direct
continuation of the roots of their characteristic polynomials:

  sparse N=6, g=3: R=1 and R=5, generated group orders 2 and 720;
  quartic m=r=2, delta=3/4: R=0.1, 2 and 30, orders 2, 8 and 24;
  equal blocks m=2, r=3, delta=1/20: R=0.01, nearby group order 72;
  vanishing-trace-certificate six-mode example: R=0.01, one six-cycle.
  unequal J3 direct-sum J1: R=1 and R=12, generated orders 4 and 24;
    the zero meridian is a full four-cycle. Here
    P=(lambda^2-t)^2-t*lambda^3, lambda=s^2/(1-s), t=s^4/(1-s),
    with finite branch values 0 and -256/27.

The code constructs a common nonreal basepoint in each disk. A meridian
uses a straight stem, a polygonal counterclockwise circle around one
branch point and the reversed stem. Distances of every polygon segment
from every finite branch point are checked, as are winding numbers and
the disk constraint. Thus no stem silently runs through t=0 or another
collision value. All branch points, basepoints, circle radii and clearances
are retained in the JSON report.

At each parameter value NumPy computes all polynomial roots. The sheet
assignment minimizes the total squared displacement over all N! possible
assignments (N<=6). A step is bisected when its root displacement exceeds
0.15 of the smaller endpoint root separation. Each loop is run with 128
and 256 circle segments and proportionately sampled stems; the complete
labeled permutations must agree. There are eighteen meridians per
resolution, hence thirty-six complete loop runs. Exact integer permutation closure gives
the generated finite-group order. The imprimitive examples also retain
the equal-sized block partitions preserved by the computed group.

The report contains minimum root separation, maximum accepted step ratio,
normalized polynomial residual, endpoint-fiber error and refinement counts.
The largest normalized polynomial residual in the reported reference run is below
1.4e-14. The report identifies the NumPy version used.

These are numerical implementation checks, NOT certified path tracking.
No interval arithmetic, rigorous root-enclosure theorem or formal proof
checker is used. Matching results at two resolutions and small residuals
are useful independent evidence, but do not prove that every intermediate
sheet assignment is correct. The all-parameter conclusions remain the
theorems proved in the manuscript. The computations do not verify a full
braid-group image, physical dynamics or experimental state transfer.
