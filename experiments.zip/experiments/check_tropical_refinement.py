"""Exact sparse-profile checks and floating root continuation for Newton refinement.

Run with --output-root DIRECTORY. Only NumPy and Matplotlib are required.
The finite checks supplement the analytic proofs; tracking is not certified.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction as F
from math import comb, gcd, cos, pi
import argparse
from itertools import permutations
import json
import numpy as np


def determinant(matrix):
    a=[row[:] for row in matrix]; n=len(a); previous=1; sign=1
    if not n:return 1
    for k in range(n-1):
        pivot=next((i for i in range(k,n) if a[i][k]),None)
        if pivot is None:return 0
        if pivot!=k:a[k],a[pivot]=a[pivot],a[k];sign=-sign
        value=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator=a[i][j]*value-a[i][k]*a[k][j]
                quotient,remainder=divmod(numerator,previous)
                assert not remainder
                a[i][j]=quotient
            a[i][k]=0
        previous=value
    return sign*a[-1][-1]


def matrices(m,r,q):
    n=m*r;A=[[0]*n for _ in range(n)];B=[[0]*n for _ in range(n)]
    for i in range(r):
        for j in range(m-1):A[i*m+j][i*m+j+1]=1
        B[(i+1)*m-1][i*m]=1
        if i<r-1:B[(i+1)*m-1][(i+1)*m]=1
    B[n-1][q]=1
    return A,B


def coefficients(m,r,q,t):
    a=np.zeros(m*r+1,dtype=complex)
    for k in range(r+1):a[k*m]+=comb(r,k)*(-t)**(r-k)
    a[q]-=t**r
    return a


def exact_coefficients(m,r,q,t):
    a=[0]*(m*r+1)
    for k in range(r+1):a[k*m]+=comb(r,k)*(-t)**(r-k)
    a[q]-=t**r
    return a


def sylvester_discriminant(coeffs):
    n=len(coeffs)-1;p=list(reversed(coeffs));derivative=[(n-i)*p[i] for i in range(n)]
    syl=[]
    for i in range(n-1):syl.append([0]*i+p+[0]*(n-2-i))
    for i in range(n):syl.append([0]*i+derivative+[0]*(n-1-i))
    return (-1)**(n*(n-1)//2)*determinant(syl)


def ring_add(a,b):return tuple(x+y for x,y in zip(a,b))
def ring_scale(a,c):return tuple(c*x for x in a)
def ring_multiply(a,b,kappa):
    q=len(a);out=[F(0)]*q
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            degree=i+j
            out[degree%q]+=x*y*(kappa if degree>=q else 1)
    return tuple(out)
def ring_power(a,n,kappa):
    assert n>=0
    ans=(F(1),)+(F(0),)*(len(a)-1)
    while n:
        if n&1:ans=ring_multiply(ans,a,kappa)
        a=ring_multiply(a,a,kappa);n//=2
    return ans


def critical_ring_check(m,r,q):
    n=m*r;kappa=F(-n,n-q);one=(F(1),)+(F(0),)*(q-1)
    s=(kappa,) if q==1 else (F(0),F(1))+(F(0),)*(q-2)
    power=lambda x,k:ring_power(x,k,kappa)
    product=lambda a,b:ring_multiply(a,b,kappa)
    lam=power(s,r);t=ring_scale(power(s,n),1/(1+kappa))
    x=ring_add(power(lam,m),ring_scale(t,-1))
    p=ring_add(power(x,r),ring_scale(product(power(t,r),power(lam,q)),-1))
    pl=ring_add(ring_scale(product(power(lam,m-1),power(x,r-1)),r*m),ring_scale(product(power(t,r),power(lam,q-1)),-q))
    pt=ring_add(ring_scale(power(x,r-1),-r),ring_scale(product(power(t,r-1),power(lam,q)),-r))
    pll=ring_add(ring_scale(product(power(lam,m-2),power(x,r-1)),r*m*(m-1)),ring_scale(product(power(lam,2*m-2),power(x,r-2)),r*(r-1)*m*m))
    if q>=2:pll=ring_add(pll,ring_scale(product(power(t,r),power(lam,q-2)),-q*(q-1)))
    assert not any(p) and not any(pl) and any(pt) and any(pll)
    target=F((-1)**(n+q)*n**n,q**q*(n-q)**(n-q))
    assert power(t,q)==ring_scale(one,target)
    return {'m':m,'r':r,'q':q,'critical_field_relation':f's^{q}={kappa}',
            'exact_P_and_P_lambda_zero':True,'exact_P_t_and_P_lambdalambda_nonzero':True,
            'critical_t_power':str(target)}


def exact_checks():
    records=[];det_count=0
    for m in range(2,6):
        for r in range(2,5):
            for q in range(1,m):
                n=m*r;A,B=matrices(m,r,q);ends=[(i+1)*m-1 for i in range(r)];heads=[i*m for i in range(r)]
                assert sum(bool(x) for row in B for x in row)==2*r
                assert sum(any(row) for row in B)==r
                assert determinant([[B[i][j] for j in heads] for i in ends])==1
                gram=[[sum(B[i][k]*B[j][k] for k in range(n)) for j in ends] for i in ends]
                assert gram==[[2 if i==j else int(abs(i-j)==1) for j in range(r)] for i in range(r)]
                count=0
                for lam in range(n+1):
                    for t in range(r+1):
                        full=[[(lam if i==j else 0)-A[i][j]-t*B[i][j] for j in range(n)] for i in range(n)]
                        assert determinant(full)==(lam**m-t)**r-t**r*lam**q
                        count+=1
                det_count+=count
                records.append({'m':m,'r':r,'q':q,'degree':n,'rank':r,'support':2*r,
                                'full_integer_determinants':count,'complete_degree_bounds':[n,r],
                                'predicted_local_cycle_lengths':[n//gcd(r,q)]*gcd(r,q)})
    discriminants=[]
    for q in [1,3]:
        m,r=4,2;n=m*r;bound=2*r*(n-1);power=r*(n-1)+(r-1)*q;sign=(-1)**((n-1)*(n+2)//2)
        for t in range(bound+1):
            expected=sign*t**power*(n**n-(-1)**(n+q)*q**q*(n-q)**(n-q)*t**q)
            assert sylvester_discriminant(exact_coefficients(m,r,q,t))==expected
        discriminants.append({'m':m,'r':r,'q':q,'sylvester_dimension':2*n-1,'complete_t_degree_bound':bound,'full_sylvester_determinants':bound+1,'discriminant_t_power':power})
    return {'status':'passed','profile_cases':len(records),'full_integer_determinants':det_count,
            'profiles':records,'discriminant_checks':discriminants,
            'full_sylvester_determinants':sum(x['full_sylvester_determinants'] for x in discriminants),
            'exact_critical_checks':[critical_ring_check(4,2,q) for q in [1,3]]}


def assignment(cost):
    """Square minimum-cost assignment by primal-dual augmenting paths."""
    n=len(cost);u=[0.]*(n+1);v=[0.]*(n+1);p=[0]*(n+1);way=[0]*(n+1)
    for i in range(1,n+1):
        p[0]=i;j0=0;minv=[float('inf')]*(n+1);used=[False]*(n+1)
        while True:
            used[j0]=True;i0=p[j0];delta=float('inf');j1=0
            for j in range(1,n+1):
                if not used[j]:
                    cur=float(cost[i0-1,j-1])-u[i0]-v[j]
                    if cur<minv[j]:minv[j]=cur;way[j]=j0
                    if minv[j]<delta:delta=minv[j];j1=j
            for j in range(n+1):
                if used[j]:u[p[j]]+=delta;v[j]-=delta
                else:minv[j]-=delta
            j0=j1
            if p[j0]==0:break
        while True:
            j1=way[j0];p[j0]=p[j1];j0=j1
            if j0==0:break
    ans=[0]*n
    for j in range(1,n+1):ans[p[j]-1]=j-1
    return np.array(ans,dtype=int)


def assignment_checks():
    rng=np.random.default_rng(20261028);count=0;gap=0.
    for n in range(2,7):
        for _ in range(5):
            cost=rng.normal(size=(n,n))**2
            got=assignment(cost)
            value=sum(cost[i,got[i]] for i in range(n))
            expected=min(sum(cost[i,p[i]] for i in range(n)) for p in permutations(range(n)))
            difference=abs(value-expected);assert difference<1e-12
            gap=max(gap,difference);count+=1
    return {'exhaustive_assignment_test_cases':count,'maximum_cost_gap':gap}


def separation(z):
    d=abs(z[:,None]-z[None,:]);np.fill_diagonal(d,np.inf);return float(d.min())

def cycle_type(p):
    left=set(range(len(p)));out=[]
    while left:
        x=min(left);count=0
        while x in left:left.remove(x);count+=1;x=p[x]
        out.append(count)
    return sorted(out,reverse=True)


def track_circle(m,r,q,rho,segments):
    theta=np.linspace(0,2*pi,segments+1);points=rho*np.exp(1j*theta);points[-1]=points[0]
    winding=float(np.angle(points[1:]/points[:-1]).sum()/(2*pi));assert abs(winding-1)<1e-12
    root=lambda t:np.roots(coefficients(m,r,q,t)[::-1])
    initial=np.array(sorted(root(points[0]),key=lambda x:(float(np.angle(x)),float(abs(x)))))
    current=initial.copy();path=[current.copy()];metrics={'root_evaluations':1,'adaptive_bisections':0,'maximum_normalized_polynomial_residual':0.,'minimum_root_separation':separation(initial),'maximum_step_separation_ratio':0.,'winding_about_zero':winding,'maximum_parameter_modulus':float(max(abs(points)))}
    def record(t,z):
        c=coefficients(m,r,q,t);a=abs(np.polynomial.polynomial.polyval(z,c));b=np.polynomial.polynomial.polyval(abs(z),abs(c));res=float(np.max(a/np.maximum(b,np.finfo(float).tiny)))
        metrics['maximum_normalized_polynomial_residual']=max(metrics['maximum_normalized_polynomial_residual'],res)
        metrics['minimum_root_separation']=min(metrics['minimum_root_separation'],separation(z))
    def advance(t0,z0,t1,depth=0):
        zz=root(t1);zz=zz[assignment(abs(z0[:,None]-zz[None,:])**2)];metrics['root_evaluations']+=1
        ratio=float(max(abs(zz-z0))/min(separation(z0),separation(zz)))
        if ratio>.15:
            assert depth<20
            metrics['adaptive_bisections']+=1;mid=(t0+t1)/2
            zmid=advance(t0,z0,mid,depth+1);return advance(mid,zmid,t1,depth+1)
        record(t1,zz);metrics['maximum_step_separation_ratio']=max(metrics['maximum_step_separation_ratio'],ratio);return zz
    record(points[0],current)
    for t0,t1 in zip(points[:-1],points[1:]):current=advance(t0,current,t1);path.append(current.copy())
    image=assignment(abs(current[:,None]-initial[None,:])**2).tolist()
    error=float(max(abs(current-initial[image])));assert error<1e-8
    expected=sorted([m*r//gcd(r,q)]*gcd(r,q),reverse=True);assert cycle_type(image)==expected
    assert metrics['maximum_normalized_polynomial_residual']<1e-11
    return {'m':m,'r':r,'q':q,'radius':rho,'circle_segments':segments,'permutation_images':image,'cycle_type':cycle_type(image),'endpoint_error':error,**metrics},theta,np.array(path)


def make_figure(figures,trajectories,thresholds):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    plt.rcParams.update({'font.size':9,'axes.titlesize':9.5,'axes.labelsize':9,'svg.fonttype':'none','pdf.fonttype':42})
    fig=plt.figure(figsize=(5.7,4.55));grid=fig.add_gridspec(2,2,height_ratios=[.85,1.15],hspace=.42,wspace=.36)
    ax=fig.add_subplot(grid[0,0]);edge=np.array([[0,2],[3,1],[6,0]])
    ax.plot(edge[:,0],edge[:,1],'-o',color='black',lw=1.4,label='Newton edge')
    ax.scatter([1],[2],s=68,color='#1373b7',marker='o',label=r'$q=1$: $t^2\lambda$')
    ax.scatter([2],[2],s=64,color='#db5735',marker='s',label=r'$q=2$: $t^2\lambda^2$')
    ax.annotate(r'$T(x)=\min(2,6x)$',xy=(3,1),xytext=(2.9,1.72),fontsize=8.5)
    ax.set(xlim=(-.3,6.4),ylim=(-.2,2.6),xlabel=r'power of $\lambda$',ylabel=r'valuation in $t$',title='(a) Same first tropical data')
    ax.legend(frameon=False,fontsize=8.5,loc='lower left',bbox_to_anchor=(0,-.055),borderaxespad=.3);ax.spines[['top','right']].set_visible(False)
    ax=fig.add_subplot(grid[0,1]);rr=[x['radius'] for x in thresholds]
    bars=ax.bar([0,1],rr,width=.55,color=['#1373b7','#db5735'])
    for bar,value in zip(bars,rr):ax.text(bar.get_x()+bar.get_width()/2,value+.4,f'{value:.4f}',ha='center',fontsize=9)
    ax.set(xticks=[0,1],xticklabels=[r'$q=1$',r'$q=3$'],ylabel=r'universality radius $R_q$',ylim=(0,max(rr)*1.24),title='(b) Fixed resources, eight modes')
    ax.text(.5,.96,r'rank $2$, support $4$, $\|B_q\|_2=\sqrt{3}$',transform=ax.transAxes,ha='center',fontsize=9)
    ax.spines[['top','right']].set_visible(False)
    colors=plt.get_cmap('tab10').colors
    for j,q in enumerate([1,2]):
        theta,path,record=trajectories[q];ax=fig.add_subplot(grid[1,j],projection='3d')
        for k in range(path.shape[1]):
            z=path[:,k]
            ax.plot(z.real,z.imag,theta/(2*pi),color=colors[k],lw=1.45)
            ax.scatter([z[0].real,z[-1].real],[z[0].imag,z[-1].imag],[0,1],s=13,color=[colors[k]])
            ax.plot([z[0].real]*2,[z[0].imag]*2,[0,1],color='#cccccc',lw=.45,alpha=.7)
        partition='(6)' if q==1 else '(3, 3)'
        ax.set(xlabel=r'$\mathrm{Re}\,\lambda$',ylabel=r'$\mathrm{Im}\,\lambda$',zlabel='',title=f'({chr(99+j)}) q={q}: cycles {partition}')
        ax.text2D(.00,.93,r'height: $\arg(t)/(2\pi)$',transform=ax.transAxes,fontsize=9)
        ax.view_init(elev=22,azim=-56);ax.set_box_aspect((1,1,1.1));ax.set_xticks([-.3,0,.3]);ax.set_yticks([-.3,0,.3]);ax.set_zticks([0,.5,1]);ax.tick_params(labelsize=9,pad=-2);ax.xaxis.labelpad=-3;ax.yaxis.labelpad=-3;ax.zaxis.labelpad=0
    fig.subplots_adjust(left=.09,right=.94,bottom=.06,top=.94)
    for ext in ['pdf','svg','png']:fig.savefig(figures/f'tropical_refinement.{ext}',dpi=220 if ext=='png' else None,bbox_inches='tight')
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-root',type=Path,required=True);args=parser.parse_args()
    out=args.output_root.resolve();results=out/'results';figures=out/'figures';results.mkdir(parents=True,exist_ok=True);figures.mkdir(parents=True,exist_ok=True)
    report=exact_checks();report.update(assignment_checks());report['continuation_certified']=False;report['continuation_scope']='Small-circle floating continuation only; global groups and exact threshold statements follow from the proof.'
    loops=[];trajectories={};arrays={}
    for m,r,qs in [(3,2,[1,2]),(4,2,[1,3])]:
        for q in qs:
            runs=[]
            for segments in [128,256]:
                row,theta,path=track_circle(m,r,q,.03,segments);runs.append(row);loops.append(row)
                if m==3 and segments==256:trajectories[q]=(theta,path,row);arrays[f'q{q}_roots']=path;arrays['theta']=theta
            assert runs[0]['permutation_images']==runs[1]['permutation_images']
    thresholds=[]
    for q in [1,3]:
        n=8;radius=(n**n/(q**q*(n-q)**(n-q)))**(1/q)
        thresholds.append({'m':4,'r':2,'q':q,'radius':radius,'critical_polynomial_constant':n**n,'critical_polynomial_tq_coefficient':-(-1)**(n+q)*q**q*(n-q)**(n-q),'rank':2,'support':4,'operator_norm':2*cos(pi/6)})
    assert thresholds[1]['radius']<thresholds[0]['radius']
    report['continuation_runs']=loops;report['continuation_run_count']=len(loops);report['same_labels_after_refinement']=True;report['fixed_resource_thresholds']=thresholds
    report['maximum_normalized_root_residual']=max(x['maximum_normalized_polynomial_residual'] for x in loops)
    report['scope']='Finite exact matrix and discriminant checks plus floating illustrations. General statements rely on the analytic proofs.'
    (results/'tropical_refinement_report.json').write_text(json.dumps(report,indent=2)+'\n');np.savez_compressed(results/'tropical_refinement_trajectories.npz',**arrays)
    make_figure(figures,trajectories,thresholds)
    print(json.dumps({k:report[k] for k in ['status','profile_cases','full_integer_determinants','full_sylvester_determinants','continuation_run_count','maximum_normalized_root_residual','fixed_resource_thresholds']},indent=2))

if __name__=='__main__':main()
