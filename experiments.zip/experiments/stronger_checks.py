"""Independent exact algebra and permutation checks for the stronger results.

The characteristic/cofactor checks use rational Gaussian elimination on a
complete interpolation grid, without using a determinant lemma.  Group
enumeration checks canonical abstract generators, not numerically traced
matrix loops.  The analytical proofs identify the actual loop generators.
"""
from fractions import Fraction as Q
from itertools import permutations
from collections import deque
import math
import random


def exact_matrix(m, delta):
    n = 2 * m
    a = [[Q(0) for _ in range(n)] for _ in range(n)]
    for start in (0, m):
        for j in range(m - 1):
            a[start + j][start + j + 1] = Q(1)
    b = [[Q(0) for _ in range(n)] for _ in range(n)]
    b[m - 1][0] = Q(2)
    b[2 * m - 1][0] = Q(1)
    b[m - 2][m] = Q(1)
    b[m - 1][m] = -(Q(1) + Q(delta))
    return a, b


def determinant(matrix):
    a = [[Q(x) for x in row] for row in matrix]
    n = len(a)
    answer = Q(1)
    for k in range(n):
        pivot = next((j for j in range(k, n) if a[j][k]), None)
        if pivot is None:
            return Q(0)
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            answer = -answer
        value = a[k][k]
        answer *= value
        for i in range(k + 1, n):
            ratio = a[i][k] / value
            for j in range(k + 1, n):
                a[i][j] -= ratio * a[k][j]
            a[i][k] = Q(0)
    return answer


def spectral_matrix(a, b, lam, t):
    n = len(a)
    return [[(Q(lam) if i == j else Q(0)) - a[i][j] - Q(t) * b[i][j]
             for j in range(n)] for i in range(n)]


def exact_polynomial_checks():
    report = []
    for m in (2, 3, 4):
        n = 2 * m
        counts = {"determinants": 0, "cofactors": 0}
        for delta in (0, 1):
            a, b = exact_matrix(m, delta)
            for t in (0, 1, 2):
                for lam in range(n + 1):
                    matrix = spectral_matrix(a, b, lam, t)
                    expected = (Q(lam) ** m - t) ** 2 - t * t * (lam - delta)
                    if determinant(matrix) != expected:
                        raise ValueError((m, delta, t, lam, "determinant"))
                    counts["determinants"] += 1
                for lam in range(n):
                    matrix = spectral_matrix(a, b, lam, t)
                    minor = [row[1:] for row in matrix[1:]]
                    if determinant(minor) != Q(lam) ** (n - 1):
                        raise ValueError((m, delta, t, lam, "cofactor"))
                    counts["cofactors"] += 1
        report.append({"m": m, **counts,
                       "grid_status": "complete interpolation grid",
                       "degree_bounds": {"lambda_det": n, "lambda_cofactor": n-1,
                                         "t": 2, "delta": 1}})
    return report


def identity(n):
    return tuple(range(n))


def compose(p, q):
    """Algebraic product p*q: q acts first."""
    return tuple(p[q[i]] for i in range(len(p)))


def inverse(p):
    result = [0] * len(p)
    for i, j in enumerate(p):
        result[j] = i
    return tuple(result)


def from_cycles(n, cycles):
    p = list(range(n))
    for cycle in cycles:
        for i, j in zip(cycle, cycle[1:] + cycle[:1]):
            p[i] = j
    return tuple(p)


def group_order(generators):
    n = len(generators[0])
    seen = {identity(n)}
    queue = deque(seen)
    while queue:
        p = queue.popleft()
        for g in generators:
            q = compose(p, g)
            if q not in seen:
                seen.add(q)
                queue.append(q)
    return len(seen)


def canonical_groups(m):
    n = 2 * m
    a = from_cycles(n, [list(range(m)), list(range(m, n))])
    b = from_cycles(n, [[0, m]])
    c = compose(a, b)
    d = from_cycles(n, [[0, c[0]]])
    return a, b, c, d


def compiler_generators(n):
    return (from_cycles(n, [list(range(1, n))]),
            from_cycles(n, [[0, 1]]))


def star_word(j, n):
    """Conjugate (0,1) into (0,j), using a shortest cyclic exponent."""
    if not 1 <= j < n:
        raise ValueError("star endpoint must be nonzero")
    k = j - 1
    if k > (n - 1) // 2:
        k -= n - 1
    token = "R" if k >= 0 else "R-"
    back = "R-" if k >= 0 else "R"
    return [token] * abs(k) + ["T"] + [back] * abs(k)


def permutation_cycles(p):
    seen = set()
    cycles = []
    for first in range(len(p)):
        if first in seen:
            continue
        cycle = []
        j = first
        while j not in seen:
            seen.add(j)
            cycle.append(j)
            j = p[j]
        if len(cycle) > 1:
            cycles.append(cycle)
    return cycles


def compile_permutation(p):
    """A word in R, R^-1 and T with algebraic product equal to p.

    Words are written in mathematical product order (rightmost acts first).
    A physical chronological command list is the reverse of this list.
    """
    n = len(p)
    if sorted(p) != list(range(n)):
        raise ValueError("not a permutation")
    word = []
    star_count = 0
    for cycle in permutation_cycles(p):
        if 0 in cycle:
            j = cycle.index(0)
            cycle = cycle[j:] + cycle[:j]
            endpoints = cycle[:0:-1]
        else:
            endpoints = [cycle[0]] + cycle[:0:-1] + [cycle[0]]
        star_count += len(endpoints)
        for endpoint in endpoints:
            word.extend(star_word(endpoint, n))
    return word, star_count


def evaluate_word(word, n):
    r, t = compiler_generators(n)
    maps = {"R": r, "R-": inverse(r), "T": t}
    p = identity(n)
    for token in word:
        p = compose(p, maps[token])
    return p


def group_and_compiler_checks():
    orders = []
    for m in (2, 3, 4):
        a, b, _, d = canonical_groups(m)
        observed = [group_order([a]), group_order([a, b]), group_order([a, b, d])]
        expected = [m, m * 2 ** m, math.factorial(2 * m)]
        if observed != expected:
            raise ValueError((m, observed, expected))
        orders.append({"m": m, "observed_orders": observed, "expected_orders": expected})
    rng = random.Random(713601)
    compilation = []
    for n in (4, 6, 8):
        cases = list(permutations(range(n))) if n == 4 else []
        if n != 4:
            for _ in range(100):
                p = list(range(n)); rng.shuffle(p); cases.append(tuple(p))
        lengths = []
        for p in cases:
            word, stars = compile_permutation(p)
            if evaluate_word(word, n) != p:
                raise ValueError((n, p, word))
            if stars > 2 * (n - 1) or len(word) > 2 * n * (n - 1):
                raise ValueError("compiler length bound")
            lengths.append(len(word))
        compilation.append({"n": n, "cases": len(cases), "max_word_length": max(lengths),
                            "proved_safe_bound": 2 * n * (n - 1)})
    return {"canonical_group_orders": orders, "compiler": compilation,
            "scope": "Exact finite permutation algebra; actual matrix-loop identification is analytical."}


