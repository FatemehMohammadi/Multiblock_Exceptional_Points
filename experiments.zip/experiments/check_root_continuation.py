"""Independent numerical continuation of polynomial roots along safe meridians.

This is a floating-point implementation check, not certified path tracking or
a proof of any monodromy statement. Only Python and NumPy are required.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import permutations, combinations
from math import comb, factorial, pi
from pathlib import Path
import json
import numpy as np


@dataclass
class Family:
    name: str
    degree: int
    branch_points: list[complex]
    radii: list[float]
    expected_orders: list[int]
    kind: str
    m: int = 0
    r: int = 0
    delta: float = 0

    def coefficients(self, t: complex) -> np.ndarray:
        """Ascending coefficients of the actual characteristic polynomial."""
        a = np.zeros(self.degree + 1, dtype=complex)
        if self.kind == 'sparse':
            a[self.degree], a[1], a[0] = 1, -t**self.r, -t**self.r
        elif self.kind == 'equal':
            for k in range(self.r + 1):
                a[k * self.m] += comb(self.r, k) * (-t)**(self.r - k)
            a[1] -= t**self.r
            a[0] += self.delta * t**self.r
        elif self.kind == 'zero_certificate':
            a[6], a[3], a[0] = 1, -2*t-t*t, t*t
        elif self.kind == 'unequal_J3_J1':
            
            
            
            a[4], a[3], a[2], a[0] = 1, -t, -2*t, t*t
        else:
            raise ValueError(self.kind)
        return a


def encode(z):
    return {'real': float(np.real(z)), 'imag': float(np.imag(z))}


def separation(roots):
    d = abs(roots[:, None] - roots[None, :])
    np.fill_diagonal(d, np.inf)
    return float(np.min(d))


def segment_distance(a, b, c):
    if a == b:
        return abs(a-c)
    s = max(0., min(1., ((c-a) * np.conj(b-a)).real / abs(b-a)**2))
    return float(abs(a+s*(b-a)-c))


def loop_vertices(base, c, points, radius, samples):
    """Straight stem followed by a regular polygon, then the reversed stem.

    For these displayed cases the direct stems stay clear of every other
    branch point. We check that geometric property; there is no hidden stem
    crossing a puncture and no continuation across t=0.
    """
    other = [abs(c-z) for z in points if abs(c-z) > 1e-13]
    ring_radius = min(.18 * min(other), .12 * radius, .30 * (radius-abs(c)))
    direction = (base-c) / abs(base-c)
    start = c + ring_radius*direction
    stem = np.linspace(base, start, samples//2+1)
    ring = c + ring_radius*direction*np.exp(2j*pi*np.arange(samples+1)/samples)
    ring[-1] = start
    vertices = np.concatenate((stem, ring[1:], stem[-2::-1]))
    clearance = min(segment_distance(a,b,z) for a,b in zip(vertices[:-1],vertices[1:]) for z in points)
    assert clearance > .20 * ring_radius, (clearance, ring_radius)
    assert max(abs(vertices)) < radius
    winding = []
    for z in points:
        w = np.angle((vertices[1:]-z)/(vertices[:-1]-z)).sum()/(2*pi)
        assert abs(w-round(w)) < 1e-9
        winding.append(int(round(w)))
    assert winding == [int(abs(c-z)<1e-13) for z in points], winding
    return vertices, {'center': encode(c), 'ring_radius': ring_radius,
                      'polygon_clearance_from_all_branch_points': clearance,
                      'winding_numbers_in_listed_branch_order': winding,
                      'maximum_parameter_modulus': float(max(abs(vertices)))}


def root_assignment(old, new, all_permutations):
    costs = abs(old[:, None]-new[None, :])**2
    totals = costs[np.arange(len(old))[None,:], all_permutations].sum(axis=1)
    return new[all_permutations[int(np.argmin(totals))]]


def track(family, vertices, all_permutations):
    def roots(t):
        return np.roots(family.coefficients(t)[::-1])
    initial = roots(vertices[0])
    initial = np.array(sorted(initial, key=lambda z:(float(np.angle(z)),float(abs(z)))))
    current = initial.copy()
    metrics = {'root_evaluations': 1, 'adaptive_bisections': 0,
               'minimum_root_separation': separation(current),
               'maximum_accepted_step_to_separation_ratio': 0.,
               'maximum_normalized_polynomial_residual': 0.}

    def record(t, rr):
        a=family.coefficients(t)
        numerator=abs(np.polynomial.polynomial.polyval(rr,a))
        denominator=np.polynomial.polynomial.polyval(abs(rr),abs(a))
        metrics['maximum_normalized_polynomial_residual']=max(
            metrics['maximum_normalized_polynomial_residual'],
            float(np.max(numerator/np.maximum(denominator,np.finfo(float).tiny))))
        metrics['minimum_root_separation']=min(metrics['minimum_root_separation'],separation(rr))

    def advance(t0, rr0, t1, depth=0):
        rr1 = root_assignment(rr0, roots(t1), all_permutations)
        metrics['root_evaluations'] += 1
        ratio = float(max(abs(rr1-rr0)) / min(separation(rr0),separation(rr1)))
        if ratio > .15:
            if depth >= 20:
                raise RuntimeError('Continuation refinement exhausted')
            metrics['adaptive_bisections'] += 1
            middle=(t0+t1)/2
            mid_roots=advance(t0,rr0,middle,depth+1)
            return advance(middle,mid_roots,t1,depth+1)
        metrics['maximum_accepted_step_to_separation_ratio']=max(
            metrics['maximum_accepted_step_to_separation_ratio'],ratio)
        record(t1,rr1)
        return rr1

    record(vertices[0],current)
    for t0,t1 in zip(vertices[:-1],vertices[1:]):
        current=advance(t0,current,t1)
    
    
    endpoint_images=np.argmin(abs(current[:,None]-initial[None,:]),axis=1)
    assert len(set(endpoint_images.tolist())) == family.degree
    mismatch=float(max(abs(current-initial[endpoint_images])))
    assert mismatch < 1e-8*max(1.,float(max(abs(initial))))
    assert metrics['maximum_normalized_polynomial_residual'] < 1e-11
    metrics['endpoint_fiber_error']=mismatch
    return endpoint_images.tolist(), metrics


def cycle_type(p):
    unused=set(range(len(p))); sizes=[]
    while unused:
        j=min(unused); n=0
        while j in unused:
            unused.remove(j);n+=1;j=p[j]
        sizes.append(n)
    return sorted(sizes,reverse=True)


def generated_group(generators):
    n=len(generators[0]); identity=tuple(range(n)); group={identity}; frontier=[identity]
    while frontier:
        p=frontier.pop()
        for q in generators:
            r=tuple(p[q[i]] for i in range(n))
            if r not in group:group.add(r);frontier.append(r)
    return group


def invariant_equal_partitions(group, block_size):
    """Return unordered equal-block partitions preserved by all group elements."""
    n=len(next(iter(group))); universe=frozenset(range(n))
    def partitions_of(remaining):
        if not remaining:
            yield frozenset(); return
        first=min(remaining)
        for others in combinations(sorted(remaining-{first}),block_size-1):
            block=frozenset((first,*others))
            for rest in partitions_of(remaining-block):yield rest|{block}
    good=[]
    for partition in partitions_of(universe):
        if all(frozenset(frozenset(p[x] for x in block) for block in partition)==partition for p in group):
            good.append(sorted([sorted(block) for block in partition]))
    return good


def make_families():
    n,g=6,3
    b=(-1)**(n+1)*n**n/(n-1)**(n-1)
    stars=[abs(b)**(1/g)*np.exp(1j*(np.angle(complex(b))+2*pi*k)/g) for k in range(g)]
    sparse=Family('sparse_N6_g3',6,[0j,*stars],[1.,5.],[2,720],'sparse',r=g)
    quartic=Family('quartic_m2_r2_delta_3_over_4',4,[0j,14/27+0j,-18+0j],
                   [.1,2.,30.],[2,8,24],'equal',m=2,r=2,delta=.75)
    m,r,delta=2,3,.05
    q=np.array([m*r-1,m*r,0.,-delta])
    critical_y=np.roots(q)
    values=[(y**r+delta)**m/(1+y) for y in critical_y]
    values=sorted(values,key=abs)
    cluster=Family('nearby_cluster_m2_r3_delta_1_over_20',6,[0j,*values],
                   [.01],[72],'equal',m=m,r=r,delta=delta)
    zero=Family('zero_certificate_full_six_cycle',6,[0j,-4+0j],
                [.01],[6],'zero_certificate')
    unequal=Family('unequal_J3_J1_full_four_cycle',4,[0j,-256/27+0j],
                   [1.,12.],[4,24],'unequal_J3_J1')
    return [sparse,quartic,cluster,zero,unequal]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('root_continuation_report.json'))
    parser.add_argument('--resolutions',type=int,nargs=2,default=[128,256])
    args=parser.parse_args()
    report={'status':'passed','method':'Floating-point polynomial-root continuation with minimum-cost full assignment and adaptive step bisection.',
            'certified':False,'scope':'Numerical evidence only; no interval arithmetic, certified homotopy tracking or proof of the all-parameter claims.',
            'numpy_version':np.__version__,'resolutions':args.resolutions,
            'permutation_convention':'Images of the deterministic initial fiber; rightmost factor acts first.', 'cases':[]}
    for family in make_families():
        perm=np.array(list(permutations(range(family.degree))),dtype=int)
        for radius,expected in zip(family.radii,family.expected_orders):
            base=.70*radius*np.exp(.731j)
            included=[c for c in family.branch_points if abs(c)<radius]
            runs=[]
            for samples in args.resolutions:
                generators=[];loops=[]
                for c in included:
                    vertices,geometry=loop_vertices(base,c,family.branch_points,radius,samples)
                    image,metrics=track(family,vertices,perm)
                    generators.append(image)
                    loops.append({**geometry,'permutation_images':image,'cycle_type':cycle_type(image),**metrics})
                group=generated_group(generators)
                assert len(group)==expected,(family.name,radius,len(group),expected)
                runs.append({'circle_segments':samples,'group_order':len(group),'loops':loops})
            assert [x['permutation_images'] for x in runs[0]['loops']]==[x['permutation_images'] for x in runs[1]['loops']]
            item={'family':family.name,'degree':family.degree,'disk_radius':radius,'basepoint':encode(base),
                  'finite_branch_points':[encode(z) for z in family.branch_points],
                  'expected_group_order':expected,'runs':runs,'same_labeled_generators_after_refinement':True}
            if family.kind=='equal' and expected in [8,72]:
                item['preserved_equal_block_partitions']=invariant_equal_partitions(group,family.r)
                assert item['preserved_equal_block_partitions']
            report['cases'].append(item)
            print(f'{family.name}, R={radius:g}: order {expected}; both resolutions agree',flush=True)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(args.output)


if __name__=='__main__':main()
