"""Targeted floating checks complement the independently exact identities."""
import unittest
import numpy as np
from run_experiments import matrices, pointwise


class ReadoutChecks(unittest.TestCase):
    def test_stable_identity_against_direct_response_when_resolved(self):
        for m in (2,3,4):
            r=.02;da=.2;db=.7;gamma=.1;lam=.7+3j
            a,ba=matrices(m,da);_,bb=matrices(m,db)
            ga=np.linalg.inv(lam*np.eye(2*m)-a-r*ba)
            gb=np.linalg.inv(lam*np.eye(2*m)-a-r*bb)
            stable=-1j*gamma*r*(db-da)*np.outer(ga[:,m-1],gb[m,:])
            direct=-1j*gamma*(ga-gb)
            
            self.assertLess(np.linalg.norm(stable-direct),2e-15)

    def test_small_radius_constants_and_distinct_phases(self):
        for m in (2,3,4):
            row=pointwise(m,1e-7)
            for key in ("site_scaled","mixed_scaled","full_scaled"):
                self.assertLess(abs(row[key]-1),1e-6)
            self.assertLess(row["critical_a"],row["r"])
            self.assertGreater(row["critical_b"],row["r"])


if __name__=="__main__":
    unittest.main()
