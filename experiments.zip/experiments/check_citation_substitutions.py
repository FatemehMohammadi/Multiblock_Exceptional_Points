"""Exact polynomial checks for the two cited Sayyad--Starkov specializations.

Python standard library only. Equations refer to arXiv:2604.16140v3 PDF:
(66)--(70), printed p. 8; (111)--(113), printed p. 12.
No downloaded reference or archived result is used as a computational input.
"""
from itertools import permutations
from pathlib import Path
import argparse
import json


def add(a, b):
    out = a.copy()
    for power, c in b.items():
        out[power] = out.get(power, 0) + c
        if out[power] == 0:
            del out[power]
    return out


def scale(a, c):
    return {power: c*v for power, v in a.items() if c*v}


def mul(a, b):
    out = {}
    for (i, j), v in a.items():
        for (k, l), w in b.items():
            out = add(out, {(i+k, j+l): v*w})
    return out


def det(matrix):
    total = {}
    for p in permutations(range(len(matrix))):
        term = {(0, 0): (-1)**sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1, len(p)))}
        for i, j in enumerate(p):
            term = mul(term, matrix[i][j])
        total = add(total, term)
    return total


def characteristic(matrix):
    x = {(1, 0): 1}
    return det([[add(x if i == j else {}, scale(entry, -1)) for j, entry in enumerate(row)] for i, row in enumerate(matrix)])


def records():
    z, one, t = {}, {(0, 0): 1}, {(0, 1): 1}
    
    four = [[z, one, z, z], [t, z, t, z], [t, z, z, one], [z, z, t, z]]
    
    three = [[z, one, z], [z, scale(t, -1), t], [t, z, t]]
    expected_four = {(4, 0): 1, (2, 1): -2, (1, 2): -1, (0, 2): 1}
    expected_three = {(3, 0): 1, (1, 2): -1, (0, 2): -1}
    assert characteristic(four) == expected_four
    assert characteristic(three) == expected_three
    return {
        'status': 'passed',
        'source': 'Sayyad and Starkov, arXiv:2604.16140v3, 10 July 2026',
        'exact_specialized_full_matrix_determinants': 2,
        'quartic': {'pdf_equation': 113, 'printed_pdf_page': 12, 'html_equation': 140,
                    'parameters': {'dtilde21': 1, 'dtilde43': 1, 'dtilde23': 1, 'dtilde31': 1, 'dtilde24': 0, 'dtilde41': 0, 'dtilde44': 0},
                    'characteristic_polynomial': '(lambda^2-t)^2-t^2*lambda'},
        'cubic': {'pdf_equation': 70, 'printed_pdf_page': 8, 'html_equation': 83,
                  'parameters': {'dtilde21': 0, 'dtilde33': 1, 'dtilde23': 1, 'dtilde31': 1},
                  'characteristic_polynomial': 'lambda^3-t^2*(1+lambda)'},
        'scope': 'Exact algebraic content checks; equation numbering was checked separately against versioned PDF and HTML.'
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    text = json.dumps(records(), indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    print(text, end='')
