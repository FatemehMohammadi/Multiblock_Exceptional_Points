# Independent checks and readout illustrations

From the package root:

```bash
python -m unittest discover -s experiments -p 'test_*.py' -v
python experiments/run_experiments.py
```

The first command runs five targeted tests. The second regenerates the
exact algebra and permutation reports, all 93 pointwise readout records,
their raw complex resolvents and coherent port vectors, and the publication
figure. To write to a chosen output directory, use:

```bash
python experiments/run_experiments.py --output-root /absolute/new-directory
```

The scripts use Python, NumPy and Matplotlib. `stronger_checks.py` itself
uses only the standard library and rational `Fraction` arithmetic.

## Exact finite checks

The characteristic polynomial and first diagonal cofactor are verified by
full-matrix rational Gaussian elimination on complete interpolation grids
for m=2,3,4: 126 determinants and 108 cofactors. The grid is complete because
the relevant degrees in (lambda,t,delta) are bounded by (2m,2,1) for the
determinant and (2m-1,2,1) for the cofactor. These are finite instance checks;
the proofs establish the formulas for every m.

The driver also reruns the provided `verify_all_jordan.py` and
`verify_higher_rank.py` kernels in a temporary staging directory. Their
outputs are computed afresh and saved in the requested output directory. The first checker covers all 128 nonzero
nilpotent Jordan types in dimensions 2 through 10, with 5,797 full integer
determinants, nonzero rank minors and orthogonal-row Gram matrices. The
second supplies 1,332 full integer determinant checks for the equal-block
fusion construction. Both use complete interpolation grids; their reports
retain every case and degree bound separately.

The abstract canonical groups have orders (m, m*2**m, (2m)!) for m=2,3,4.
Exact enumeration checks these orders. It does not numerically certify the
matrix control paths: their identification with the canonical generators
is proved in the manuscript.

The compiler writes products in mathematical order, with the rightmost
factor acting first. Reverse its returned token list for chronological
physical commands. It is checked on every S4 permutation and 100 fixed
pseudorandom records each in S6 and S8, using seed 713601. Repeated random
permutations are retained; these 224 records are not an independent random
performance ensemble. The elementary conjugation identity is also checked
for every star endpoint in degrees 3 through 12. No target is dropped.

## Readout protocol and numerical scope

The fixed protocol uses m=2,3,4, 31 logarithmic radii from 1e-2 to 1e-7,
a=0.5, b=1.5, kappa=3, gamma=0.1, omega=0 and control t=rho. The actual
models have delta_a=a*rho**(1/m) and delta_b=b*rho**(1/m). Every recorded
pair lies on opposite sides of the evaluated exact phase threshold.

These are pointwise evaluations, not a numerical maximization over drive
frequency or control phase. Uniform-frequency supremum constants and the
binary bounded-noise statements are analytical results. No noise-realization
sampling, estimator benchmark or laboratory experiment is included.

The response difference is computed through the rank-one resolvent identity;
the site-reflection difference uses the exact cofactor formula. Subtracting
nearly equal scattering matrices would lose the small signal to floating
roundoff. Direct subtraction is used only in an independently resolved test.

The scalar coherent channel drives and reads the saved normalized coherent
port vector. All physical ports remain loaded. This is a single recorded
complex scalar but requires calibrated coherent access to multiple ports.
It is not equivalent in physical resources to coupling at one local site.

The generated `pointwise_resolvents.npz` contains all Ga/Gb arrays and the fixed coherent
port vectors, with radii and mismatch arrays for each m. The CSV/JSON supply
every contrast, leading constant, normalized ratio and critical radius.
`summary.json` retains all finite-check counts, fitting windows and versions.
The fixed power-law fit uses 19 radii satisfying rho<=1e-4. It is an
illustration of the proved asymptotics, not an inferred scaling law.

## General full-cycle, reference and continuation checks

The complete package driver `python reproduce.py` also runs the general
full-cycle construction, independent matrix/discriminant implementations,
exact reference specializations and direct numerical root continuation.
See `CONTINUATION_README.txt` and `../certificates/GENERAL_FUSION_README.txt`.
These checker scripts accept `--output` to choose the report destination.
