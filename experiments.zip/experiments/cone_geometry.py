"""Exact checks for a four-mode nilpotent-cone slice, without CAS dependencies."""
from fractions import Fraction as F
from itertools import permutations,product
import json
import argparse
from math import lcm
from pathlib import Path

NV=6 
ZERO=(0,)*NV

def const(c):return {ZERO:c} if c else {}
def variable(i):
 e=list(ZERO);e[i]=1;return {tuple(e):1}
def add(*ps):
 out={}
 for p in ps:
  for e,c in p.items():out[e]=out.get(e,0)+c
 return {e:c for e,c in out.items() if c}
def scale(p,c):return {e:c*v for e,v in p.items() if c*v}
def mul(p,q):
 out={}
 for a,c in p.items():
  for b,d in q.items():
   e=tuple(x+y for x,y in zip(a,b));out[e]=out.get(e,0)+c*d
 return {e:c for e,c in out.items() if c}
def power(p,n):
 out=const(1)
 for _ in range(n):out=mul(out,p)
 return out
def detpoly(A):
 out={};n=len(A)
 for perm in permutations(range(n)):
  term=const((-1)**sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n)))
  for i in range(n):term=mul(term,A[i][perm[i]])
  out=add(out,term)
 return out
def detint(matrix):
 A=[r[:] for r in matrix];n=len(A);sign=1;old=1
 for k in range(n-1):
  p=next((j for j in range(k,n) if A[j][k]),None)
  if p is None:return 0
  if p!=k:A[k],A[p]=A[p],A[k];sign=-sign
  pivot=A[k][k]
  for i in range(k+1,n):
   for j in range(k+1,n):
    num=A[i][j]*pivot-A[i][k]*A[k][j]
    value,rem=divmod(num,old);assert rem==0
    A[i][j]=value
   A[i][k]=0
  old=pivot
 return sign*A[-1][-1]
def run_general_checks():
 l,t,a,z,h,k=[variable(j) for j in range(NV)]
 A=[[{} for _ in range(4)] for _ in range(4)]
 for j in range(4):A[j][j]=l
 A[0][1]=A[2][3]=const(-1)
 A[1][0]=scale(mul(t,add(a,z)),-1);A[1][2]=scale(mul(t,h),-1)
 A[3][0]=scale(mul(t,k),-1);A[3][2]=scale(mul(t,add(a,scale(z,-1))),-1);A[3][1]=scale(t,-1)
 expected=add(power(add(power(l,2),scale(mul(a,t),-1)),2),scale(mul(power(t,2),add(power(z,2),mul(h,k),mul(h,l))),-1))
 assert detpoly(A)==expected
 count=0
 for aa,hh,tt in product(range(15),range(8),range(15)):
  p=[1,0,-2*aa*tt,-hh*tt**2,aa**2*tt**2];q=[4,0,-4*aa*tt,-hh*tt**2]
  mat=[]
  for shift in range(3):mat.append([0]*shift+p+[0]*(2-shift))
  for shift in range(4):mat.append([0]*shift+q+[0]*(3-shift))
  assert detint(mat)==-hh**2*tt**7*(256*aa**3+27*hh**2*tt)
  count+=1
 checks=0
 for aa,hh,u in product([F(1),F(2),F(-1)],[F(1),F(2),F(-1)],[F(1,3),F(2,3),F(3)]):
  lam=u*u/hh;tt=u**4/(hh**2*(aa+u));assert (lam**2-aa*tt)**2-hh*tt*tt*lam==0
  assert lam*lam/tt-aa==u
  checks+=1
 return {'status':'passed','symbolic_4x4_determinant':'full permutation determinant in six independent polynomial variables','sylvester_determinants':count,'complete_degree_grid':{'a':14,'h':7,'t':14},'degree_bound_reason':'Each entry of the 7x7 Sylvester matrix has a-degree<=2,h-degree<=1,t-degree<=2; every determinant term has seven factors.','rational_normalization_inverse_cases':checks,'scope':'Exact polynomial identities and normalization checks. Local/global monodromy follow from rational-cover proof, not numerical continuation.'}



def determinant_exact(matrix):
    denominator=lcm(*(F(x).denominator for row in matrix for x in row))
    integer=[[int(F(x)*denominator) for x in row] for row in matrix]
    return F(detint(integer),denominator**len(matrix))


def sylvester_matrix(coefficients, derivative):
    matrix=[]
    for shift in range(3):
        matrix.append([0]*shift+list(coefficients)+[0]*(2-shift))
    for shift in range(4):
        matrix.append([0]*shift+list(derivative)+[0]*(3-shift))
    return matrix


def check_cone_points():
    records=[];ndet=0;nsyl=0
    points=[(1,F(1,2),F(1,4),-1),(1,F(1,4),F(1,16),-1),
            (1,1,1,-1),(1,0,1,0),(1,0,0,-1),
            (1,F(1,2),F(-1,4),1),(2,F(1,2),F(1,4),-1),
            (-1,F(1,2),F(1,4),-1)]
    for aa,zz,hh,kk in points:
        aa,zz,hh,kk=map(F,(aa,zz,hh,kk))
        assert zz**2+hh*kk==0 and aa
        B=[[F(0) for _ in range(4)] for _ in range(4)]
        for i,j,value in [(1,0,aa+zz),(1,2,hh),(3,0,kk),(3,2,aa-zz),(3,1,1)]:
            B[i][j]=value
        minor=[[B[i][j] for j in [0,2]] for i in [1,3]]
        assert determinant_exact(minor)==aa**2
        assert sum(any(row) for row in B)==2
        leading=[[B[i][j] for j in [0,2]] for i in [1,3]]
        nilpotent=[[leading[i][j]-(aa if i==j else 0) for j in range(2)] for i in range(2)]
        rb=[[B[i][j] for j in [0,2]] for i in [0,2]]
        sb=[[B[i][j] for j in [1,3]] for i in [1,3]]
        certificate=sum(nilpotent[i][j]*(rb[j][i]+sb[j][i]) for i in range(2) for j in range(2))
        assert certificate==hh
        A=[[F(i==j-1 and (i,j) in [(0,1),(2,3)]) for j in range(4)] for i in range(4)]
        for lam,tt in product(range(5),range(3)):
            matrix=[[(F(lam) if i==j else 0)-A[i][j]-tt*B[i][j] for j in range(4)] for i in range(4)]
            assert determinant_exact(matrix)==(lam**2-aa*tt)**2-hh*tt**2*lam
            ndet+=1
        for tt in range(15):
            p=[1,0,-2*aa*tt,-hh*tt**2,aa**2*tt**2]
            q=[4,0,-4*aa*tt,-hh*tt**2]
            assert determinant_exact(sylvester_matrix(p,q))==-hh**2*tt**7*(256*aa**3+27*hh**2*tt)
            nsyl+=1
        entry={'a':str(aa),'z':str(zz),'h':str(hh),'k':str(kk),
               'rank_B':2,'support_B':sum(bool(x) for row in B for x in row),
               'head_end_minor':str(aa**2),'trace_certificate':str(certificate)}
        if hh:
            lam=F(16,9)*aa**2/hh;tt=-F(256,27)*aa**3/hh**2
            assert (lam**2-aa*tt)**2-hh*tt**2*lam==0
            assert 4*lam**3-4*aa*tt*lam-hh*tt**2==0
            pt=-2*aa*(lam**2-aa*tt)-2*hh*tt*lam
            pll=12*lam**2-4*aa*tt
            assert pt==F(2048,243)*aa**5/hh**2
            assert pll==F(2048,27)*aa**4/hh**2
            entry.update(critical_lambda=str(lam),critical_t=str(tt),
                         P_t=str(pt),P_lambdalambda=str(pll),
                         analytic_disk_groups=['C4','S4'])
        else:
            entry['simple_punctured_fibers']=False
        records.append(entry)
    return {'cone_points':records,'full_rational_4x4_determinants':ndet,
            'rational_7x7_Sylvester_determinants':nsyl,
            'scope':'Complete lambda-degree4,t-degree2 grids at eight rational cone points; 15-point t grids for each discriminant, including a repeated-square case.'}


def make_figure(output):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    from matplotlib.cm import ScalarMappable
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,
                        'axes.labelsize':9,'axes.titlesize':9.5,
                        'xtick.labelsize':9,'ytick.labelsize':9,
                        'legend.fontsize':8,'pdf.fonttype':42,'ps.fonttype':42})
    fig=plt.figure(figsize=(5.7,2.9))
    ax=fig.add_axes([.005,.20,.46,.70],projection='3d')
    ax.computed_zorder=False
    radii=np.linspace(.015,1.1,42)
    angles=np.linspace(0,2*np.pi,145)
    radius,angle=np.meshgrid(radii,angles,indexing='ij')
    norm=Normalize(vmin=.25,vmax=5)
    cmap=plt.get_cmap('viridis')
    for sign in [-1,1]:
        common=radius*np.cos(angle);vertical=sign*radius
        h=common+vertical;k=common-vertical;z=radius*np.sin(angle)
        h[np.abs(h)<1e-10]=np.nan
        cost=np.log10(256/27)-2*np.log10(np.abs(h))
        ax.plot_surface(h,k,z,facecolors=cmap(norm(cost)),linewidth=0,
                        antialiased=True,shade=False,rasterized=True,zorder=1)
    ax.plot([0,0],[-2.2,2.2],[0,0],color='#bc2a2a',lw=2.2,zorder=10)
    ax.set(xlabel='$h$',ylabel='$k$',zlabel='$z$',xlim=(-2.25,2.25),
           ylim=(-2.25,2.25),zlim=(-1.2,1.2))
    ax.set_xticks([-2,0,2]);ax.set_yticks([-2,0,2]);ax.set_zticks([-1,0,1])
    ax.tick_params(pad=-1);ax.xaxis.labelpad=-5;ax.yaxis.labelpad=-5;ax.zaxis.labelpad=-5
    ax.view_init(elev=23,azim=-58);ax.set_box_aspect((1,1,.72))
    ax.set_title('(a) Cone slice: $z^2+hk=0$',pad=2)
    ax.text2D(.01,.94,r'Red: $h=z=0$',transform=ax.transAxes,
              color='#bc2a2a',fontsize=9)
    cax=fig.add_axes([.055,.11,.36,.027])
    cb=fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),cax=cax,orientation='horizontal')
    cb.set_ticks([1,2,3,4,5]);cb.set_ticklabels(['1','2','3','4',r'$\geq5$'])
    cb.set_label(r'$\log_{10}R_{\rm uni}$, $a=1$',labelpad=1)
    right=fig.add_axes([.62,.23,.365,.61])
    hh=np.geomspace(.01,1,300);threshold=256/(27*hh**2)
    right.loglog(hh,threshold,color='#195b83',lw=2)
    for point in [1/16,1/4,1]:
        value=256/(27*point**2)
        right.scatter([point],[value],s=31,c=[cmap(norm(np.log10(value)))],edgecolors='black',lw=.6,zorder=3)
    fixed=1000;boundary=np.sqrt(256/(27*fixed))
    right.axhline(fixed,color='.45',ls='--',lw=1)
    right.axvline(boundary,color='.55',ls=':',lw=1)
    right.text(.0117,1200,r'$R=10^3$',color='.35',fontsize=9)
    right.text(.23,.93,r'$C_4$',transform=right.transAxes,ha='center',fontsize=9)
    right.text(.80,.93,r'$S_4$',transform=right.transAxes,ha='center',fontsize=9)
    right.set(xlim=(.01,1.15),ylim=(5,1.6e5),xlabel=r'$h$ ($k=-1$, $z=\sqrt{h}$)',
              ylabel=r'$R_{\rm uni}$')
    right.set_title(r'(b) $R_{\mathrm{uni}}=256/(27h^2)$',pad=10)
    right.grid(which='major',alpha=.2)
    right.text(.03,.04,r'$h\to0:\;R_{\rm uni}\to\infty$',transform=right.transAxes,
               ha='left',va='bottom',fontsize=9)
    output.mkdir(parents=True,exist_ok=True)
    for extension in ['pdf','svg','png']:
        fig.savefig(output/f'cone_geometry.{extension}',dpi=300,bbox_inches='tight')
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root',type=Path,default=Path(__file__).resolve().parent/'generated')
    args=parser.parse_args();out=args.output_root.resolve();out.mkdir(parents=True,exist_ok=True)
    result=run_general_checks();result.update(check_cone_points())
    (out/'cone_geometry_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    make_figure(out)
    print(json.dumps({'status':result['status'],'output_root':str(out),
                      'symbolic_4x4_determinant':'passed',
                      'general_Sylvester_determinants':result['sylvester_determinants'],
                      'rational_cone_point_determinants':result['full_rational_4x4_determinants'],
                      'rational_cone_point_Sylvester_determinants':result['rational_7x7_Sylvester_determinants']},indent=2))


if __name__=='__main__':main()
