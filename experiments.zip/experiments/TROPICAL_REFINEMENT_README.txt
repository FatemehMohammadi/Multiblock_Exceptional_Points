Higher-order Newton refinement at fixed coupling resources

Run from the repository root:
  python experiments/check_tropical_refinement.py --output-root /path/to/fresh-output
Requires NumPy and Matplotlib plus the Python standard library.

Output:
  results/tropical_refinement_report.json
  results/tropical_refinement_trajectories.npz
  figures/tropical_refinement.pdf
  figures/tropical_refinement.svg
  figures/tropical_refinement.png

The exact suite checks 30 profiles with 2<=m<=5, 2<=r<=4, 1<=q<m:
1640 full integer matrix determinants on complete degree-(mr,r)
interpolation grids. Exact rank minors and row Gram matrices check rank,
support and the fixed-norm formula. Two eight-mode discriminants receive
58 full 15-by-15 Sylvester determinants on complete degree-28 t grids.
Critical points for m=4,r=2,q=1 and q=3 are checked with exact fractions
in Q[s]/(s^q+8/(8-q)).

The minimum-cost assignment routine receives 25 exhaustive comparisons
against all permutations in dimensions two through six, using a fixed seed.
Eight floating continuation runs cover q=1,2 for J3+J3 and q=1,3 for J4+J4,
at 128 and 256 circle segments. Full labeled permutations must agree
under refinement. The script uses adaptive bisection and retains residual,
separation, endpoint and winding records. This is not certified tracking.
The general local/global groups follow from the accompanying proof; no
numerical S8 group enumeration is claimed.

All eigenvalues in the six-mode pair have leading exponent 1/3 and the
same first tropical polynomial and Newton edge polynomial. Their local
cycle partitions are (6) and (3,3). The eight-mode pair keeps minimum rank
two, sharp joint support four and operator norm sqrt(3), while its achieved
universality radii are 20.3719975763 and 5.8367178980. These are comparisons
within the stated normalized family, not global optimality claims for all
profiles or hardware realizations.

The 3D plots are root trajectories over a one-dimensional parameter circle;
they do not display the whole spectral surface or prove a full braid image.
The Newton-Puiseux and primitive-cover methods are classical. The explicit
constrained realization and quantitative resource comparison are the point
of the example.
