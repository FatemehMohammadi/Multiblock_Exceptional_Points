"""Draw the exact six-mode example of the all-Jordan construction."""
from pathlib import Path
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
from matplotlib.lines import Line2D

def draw(destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    angles = np.pi / 2 - np.arange(6) * np.pi / 3
    xy = np.column_stack((1.35 * np.cos(angles), np.sin(angles)))
    fig = plt.figure(figsize=(5.0, 1.75))
    ax = fig.add_axes([.02, .015, .46, .97])
    fixed, controlled = [(0, 1), (1, 2), (3, 4)], [(2, 3), (4, 5), (5, 0)]
    for edges, color, text in [(fixed, "#303030", "1"),
                               (controlled, "#0072B2", "$t$")]:
        for a, b in edges:
            ax.add_patch(FancyArrowPatch(xy[a], xy[b], arrowstyle="-|>",
                mutation_scale=10.5, shrinkA=11.8, shrinkB=11.8, linewidth=1.3,
                color=color, zorder=1))
            mid = 0.5 * (xy[a] + xy[b])
            ax.text(*(mid * 1.20), text, fontsize=10, ha="center", va="center",
                    color=color)
    ax.add_patch(FancyArrowPatch(xy[1], xy[3], arrowstyle="-|>",
        connectionstyle="arc3,rad=0.16", mutation_scale=10.5,
        shrinkA=12.3, shrinkB=12.3, linewidth=1.5, color="#D55E00", zorder=2))
    ax.text(0.54, -0.18, "$t$", color="#D55E00", fontsize=10)
    labels = [r"$e_{1,3}$", r"$e_{1,2}$", r"$e_{1,1}$",
              r"$e_{2,2}$", r"$e_{2,1}$", r"$e_{3,1}$"]
    fills = ["#dcecf5"] * 3 + ["#e2efd9"] * 2 + ["#f5e5c7"]
    for q, label, fill in zip(xy, labels, fills):
        ax.scatter(*q, s=500, facecolors=fill, edgecolors="#444444", zorder=3)
        ax.text(*q, label, ha="center", va="center", fontsize=10, zorder=4)
    fig.text(.54, .82, r"$A_0=J_3\oplus J_2\oplus J_1$", fontsize=10)
    fig.text(.54, .64, r"$N=6,\qquad g=3$", fontsize=10)
    legend = [Line2D([0], [0], color="#303030", lw=1.6, label="Fixed chain entry"),
              Line2D([0], [0], color="#0072B2", lw=1.6, label="Controlled closure"),
              Line2D([0], [0], color="#D55E00", lw=1.7, label="Controlled shortcut")]
    fig.legend(handles=legend, loc="center left", bbox_to_anchor=(.53, .32),
               frameon=False, fontsize=9.8, handlelength=1.7,
               handletextpad=.55, labelspacing=.40, borderaxespad=0)
    ax.set_aspect("equal"); ax.set_xlim(-1.72, 1.72); ax.set_ylim(-1.25, 1.27)
    ax.axis("off")
    for ext in ["pdf", "svg", "png"]:
        fig.savefig(destination / f"all_jordan_architecture.{ext}",
                    dpi=240, bbox_inches="tight", pad_inches=.035)
    plt.close(fig)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "figures")
    draw(parser.parse_args().output)
